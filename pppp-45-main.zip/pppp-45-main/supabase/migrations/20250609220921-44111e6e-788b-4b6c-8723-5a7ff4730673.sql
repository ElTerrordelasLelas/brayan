
-- Primero, agreguemos una columna para el nivel seleccionado en la tabla profiles
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS nivel_seleccionado text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS fecha_seleccion_nivel timestamp with time zone;

-- Creemos una tabla para las sesiones de entrenamiento completadas
CREATE TABLE IF NOT EXISTS sesiones_entrenamiento (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users NOT NULL,
  fecha timestamp with time zone DEFAULT now(),
  nivel text NOT NULL,
  dia_rutina text NOT NULL,
  ejercicios_completados integer DEFAULT 0,
  total_ejercicios integer DEFAULT 0,
  duracion_minutos integer,
  calificacion_esfuerzo integer CHECK (calificacion_esfuerzo >= 1 AND calificacion_esfuerzo <= 10),
  notas text,
  created_at timestamp with time zone DEFAULT now()
);

-- Habilitemos RLS para la tabla de sesiones
ALTER TABLE sesiones_entrenamiento ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para sesiones_entrenamiento
CREATE POLICY "Users can view their own training sessions" 
  ON sesiones_entrenamiento 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own training sessions" 
  ON sesiones_entrenamiento 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own training sessions" 
  ON sesiones_entrenamiento 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Creemos una tabla para las reservas de gimnasio (sin coach)
CREATE TABLE IF NOT EXISTS reservas_gimnasio (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users NOT NULL,
  fecha_hora timestamp with time zone NOT NULL,
  duracion_minutos integer DEFAULT 60,
  tipo_entrenamiento text DEFAULT 'libre',
  estado text DEFAULT 'confirmada' CHECK (estado IN ('confirmada', 'cancelada', 'completada')),
  notas text,
  created_at timestamp with time zone DEFAULT now()
);

-- Habilitemos RLS para reservas_gimnasio
ALTER TABLE reservas_gimnasio ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para reservas_gimnasio
CREATE POLICY "Users can view their own gym reservations" 
  ON reservas_gimnasio 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own gym reservations" 
  ON reservas_gimnasio 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own gym reservations" 
  ON reservas_gimnasio 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own gym reservations" 
  ON reservas_gimnasio 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Creemos una tabla para los tipos de medallas disponibles (plantillas)
CREATE TABLE IF NOT EXISTS tipos_medallas (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  tipo_medalla text UNIQUE NOT NULL,
  nombre text NOT NULL,
  descripcion text,
  icono text,
  criterio_tipo text NOT NULL,
  criterio_valor integer NOT NULL,
  valor_logro jsonb DEFAULT '{}'::jsonb,
  created_at timestamp with time zone DEFAULT now()
);

-- Actualicemos la tabla de medallas para que referencie los tipos
ALTER TABLE medallas ADD COLUMN IF NOT EXISTS tipo_medalla_id uuid REFERENCES tipos_medallas(id);
ALTER TABLE medallas ADD COLUMN IF NOT EXISTS fecha_obtenida_real timestamp with time zone DEFAULT now();

-- Insertemos los tipos de medallas base
INSERT INTO tipos_medallas (tipo_medalla, nombre, descripcion, icono, criterio_tipo, criterio_valor, valor_logro)
VALUES 
  ('primer_entrenamiento', 'Primera Sesión', 'Completaste tu primer entrenamiento', '🏃‍♂️', 'sesiones_completadas', 1, '{"sesiones": 1}'::jsonb),
  ('racha_semanal', 'Guerrero Semanal', 'Entrena 5 días en una semana', '🔥', 'racha_semanal', 5, '{"dias_semana": 5}'::jsonb),
  ('constancia_mensual', 'Constancia de Hierro', 'Entrena 20 días en un mes', '💪', 'constancia_mensual', 20, '{"dias_mes": 20}'::jsonb),
  ('nivel_principiante', 'Novato Dedicado', 'Completa 10 entrenamientos de nivel principiante', '🌟', 'entrenamientos_nivel', 10, '{"nivel": "principiante", "sesiones": 10}'::jsonb),
  ('nivel_intermedio', 'Atleta en Progreso', 'Completa 15 entrenamientos de nivel intermedio', '⭐', 'entrenamientos_nivel', 15, '{"nivel": "intermedio", "sesiones": 15}'::jsonb),
  ('nivel_avanzado', 'Máquina de Entrenamiento', 'Completa 20 entrenamientos de nivel avanzado', '🏆', 'entrenamientos_nivel', 20, '{"nivel": "avanzado", "sesiones": 20}'::jsonb)
ON CONFLICT (tipo_medalla) DO NOTHING;

-- Función para otorgar medallas automáticamente
CREATE OR REPLACE FUNCTION public.verificar_medallas_usuario(usuario_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    tipo_medalla_record RECORD;
    sesiones_count integer;
    sesiones_nivel_count integer;
    racha_semanal_count integer;
    dias_mes_count integer;
BEGIN
    -- Iteramos sobre todos los tipos de medallas
    FOR tipo_medalla_record IN SELECT * FROM tipos_medallas LOOP
        -- Verificamos si el usuario ya tiene esta medalla
        IF NOT EXISTS (
            SELECT 1 FROM medallas 
            WHERE user_id = usuario_id 
            AND tipo_medalla_id = tipo_medalla_record.id
        ) THEN
            -- Verificamos el criterio según el tipo
            CASE tipo_medalla_record.criterio_tipo
                WHEN 'sesiones_completadas' THEN
                    SELECT COUNT(*) INTO sesiones_count 
                    FROM sesiones_entrenamiento 
                    WHERE user_id = usuario_id;
                    
                    IF sesiones_count >= tipo_medalla_record.criterio_valor THEN
                        INSERT INTO medallas (user_id, tipo_medalla_id, nombre, descripcion, icono, activa, fecha_obtenida_real)
                        VALUES (usuario_id, tipo_medalla_record.id, tipo_medalla_record.nombre, tipo_medalla_record.descripcion, tipo_medalla_record.icono, true, now());
                    END IF;
                    
                WHEN 'entrenamientos_nivel' THEN
                    SELECT COUNT(*) INTO sesiones_nivel_count 
                    FROM sesiones_entrenamiento 
                    WHERE user_id = usuario_id 
                    AND nivel = (tipo_medalla_record.valor_logro->>'nivel');
                    
                    IF sesiones_nivel_count >= tipo_medalla_record.criterio_valor THEN
                        INSERT INTO medallas (user_id, tipo_medalla_id, nombre, descripcion, icono, activa, fecha_obtenida_real)
                        VALUES (usuario_id, tipo_medalla_record.id, tipo_medalla_record.nombre, tipo_medalla_record.descripcion, tipo_medalla_record.icono, true, now());
                    END IF;
                    
                WHEN 'racha_semanal' THEN
                    -- Contamos días únicos de entrenamiento en la semana actual
                    SELECT COUNT(DISTINCT DATE(fecha)) INTO racha_semanal_count
                    FROM sesiones_entrenamiento 
                    WHERE user_id = usuario_id 
                    AND fecha >= date_trunc('week', now())
                    AND fecha < date_trunc('week', now()) + interval '1 week';
                    
                    IF racha_semanal_count >= tipo_medalla_record.criterio_valor THEN
                        INSERT INTO medallas (user_id, tipo_medalla_id, nombre, descripcion, icono, activa, fecha_obtenida_real)
                        VALUES (usuario_id, tipo_medalla_record.id, tipo_medalla_record.nombre, tipo_medalla_record.descripcion, tipo_medalla_record.icono, true, now());
                    END IF;
                    
                WHEN 'constancia_mensual' THEN
                    -- Contamos días únicos de entrenamiento en el mes actual
                    SELECT COUNT(DISTINCT DATE(fecha)) INTO dias_mes_count
                    FROM sesiones_entrenamiento 
                    WHERE user_id = usuario_id 
                    AND fecha >= date_trunc('month', now())
                    AND fecha < date_trunc('month', now()) + interval '1 month';
                    
                    IF dias_mes_count >= tipo_medalla_record.criterio_valor THEN
                        INSERT INTO medallas (user_id, tipo_medalla_id, nombre, descripcion, icono, activa, fecha_obtenida_real)
                        VALUES (usuario_id, tipo_medalla_record.id, tipo_medalla_record.nombre, tipo_medalla_record.descripcion, tipo_medalla_record.icono, true, now());
                    END IF;
            END CASE;
        END IF;
    END LOOP;
END;
$$;
