
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

// Cleanup function for auth state
const cleanupAuthState = () => {
  try {
    // Remove all Supabase auth keys from localStorage
    Object.keys(localStorage).forEach((key) => {
      if (key.startsWith('supabase.auth.') || key.includes('sb-')) {
        localStorage.removeItem(key);
      }
    });
    
    // Remove from sessionStorage if in use
    if (typeof sessionStorage !== 'undefined') {
      Object.keys(sessionStorage).forEach((key) => {
        if (key.startsWith('supabase.auth.') || key.includes('sb-')) {
          sessionStorage.removeItem(key);
        }
      });
    }
    
    // Clear app-specific data
    localStorage.removeItem('currentUser');
    localStorage.removeItem('users');
  } catch (error) {
    console.error('Error cleaning auth state:', error);
  }
};

export const signUp = async (email: string, password: string) => {
  try {
    // Clean up any existing auth state first
    cleanupAuthState();
    
    const redirectUrl = `${window.location.origin}/`;
    
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: redirectUrl
      }
    });

    if (error) throw error;
    
    return { data, error: null };
  } catch (error: any) {
    return { data: null, error };
  }
};

export const signIn = async (email: string, password: string) => {
  try {
    // Clean up any existing auth state first
    cleanupAuthState();
    
    // Attempt global sign out first to clear any lingering sessions
    try {
      await supabase.auth.signOut({ scope: 'global' });
    } catch (err) {
      // Continue even if this fails
      console.log('Global signout failed, continuing...');
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });

    if (error) throw error;
    
    return { data, error: null };
  } catch (error: any) {
    return { data: null, error };
  }
};

export const signOut = async () => {
  try {
    // Clean up auth state first
    cleanupAuthState();
    
    // Attempt global sign out
    const { error } = await supabase.auth.signOut({ scope: 'global' });
    
    if (error) {
      console.error('Sign out error:', error);
      // Even if sign out fails, clean up local state
    }
    
    // Force page reload for clean state
    setTimeout(() => {
      window.location.href = '/';
    }, 100);
    
    return { error: null };
  } catch (error: any) {
    console.error('Sign out error:', error);
    // Force cleanup and reload even on error
    cleanupAuthState();
    window.location.href = '/';
    return { error };
  }
};

export const resetPassword = async (email: string) => {
  try {
    const redirectUrl = `${window.location.origin}/`;
    
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: redirectUrl
    });

    if (error) throw error;
    
    toast.success('Se envió un enlace de recuperación a tu email');
    return { error: null };
  } catch (error: any) {
    toast.error('Error al enviar el enlace de recuperación');
    return { error };
  }
};

export const deleteAccount = async () => {
  try {
    // First delete user data
    const { data: { user } } = await supabase.auth.getUser();
    
    if (user) {
      // Delete related data (this can be done with CASCADE in the DB)
      await Promise.all([
        supabase.from('configuraciones_usuario').delete().eq('user_id', user.id),
        supabase.from('sesiones_entrenamiento').delete().eq('user_id', user.id),
        supabase.from('medallas').delete().eq('user_id', user.id),
        supabase.from('profiles').delete().eq('id', user.id)
      ]);
    }
    
    toast.success('Cuenta eliminada exitosamente');
    // User will be logged out automatically
    return { error: null };
  } catch (error: any) {
    toast.error('Error al eliminar la cuenta');
    return { error };
  }
};

export const getCurrentUser = async () => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    return user;
  } catch (error) {
    return null;
  }
};
