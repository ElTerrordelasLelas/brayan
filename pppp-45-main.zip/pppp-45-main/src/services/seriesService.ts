
import { toast } from 'sonner';
import { saveTrainingSession } from './trainingService';

export interface ExerciseSeriesProgress {
  exerciseId: string;
  seriesCompleted: number;
  totalSeries: number;
  isCompleted: boolean;
  lastUpdated: string;
}

export interface DayProgress {
  levelTitle: string;
  dayName: string;
  exercises: Record<string, ExerciseSeriesProgress>;
  lastUpdated: string;
}

const STORAGE_KEY = 'exercise_series_progress';

export const getSeriesProgress = (exerciseId: string): ExerciseSeriesProgress => {
  try {
    const savedProgress = localStorage.getItem(STORAGE_KEY);
    if (!savedProgress) {
      return createDefaultProgress(exerciseId);
    }

    const progress: DayProgress = JSON.parse(savedProgress);
    return progress.exercises[exerciseId] || createDefaultProgress(exerciseId);
  } catch (error) {
    console.error('Error loading series progress:', error);
    return createDefaultProgress(exerciseId);
  }
};

export const getAllSeriesProgress = (): Record<string, ExerciseSeriesProgress> => {
  try {
    const savedProgress = localStorage.getItem(STORAGE_KEY);
    if (!savedProgress) {
      return {};
    }

    const progress: DayProgress = JSON.parse(savedProgress);
    return progress.exercises || {};
  } catch (error) {
    console.error('Error loading all series progress:', error);
    return {};
  }
};

export const saveSeriesProgress = async (
  exerciseId: string, 
  seriesCompleted: number,
  levelTitle: string,
  dayName: string
): Promise<ExerciseSeriesProgress> => {
  try {
    const totalSeries = 3;
    const isCompleted = seriesCompleted >= totalSeries;
    
    const newProgress: ExerciseSeriesProgress = {
      exerciseId,
      seriesCompleted,
      totalSeries,
      isCompleted,
      lastUpdated: new Date().toISOString()
    };

    // Get existing progress
    const savedProgress = localStorage.getItem(STORAGE_KEY);
    let dayProgress: DayProgress;

    if (savedProgress) {
      dayProgress = JSON.parse(savedProgress);
    } else {
      dayProgress = {
        levelTitle,
        dayName,
        exercises: {},
        lastUpdated: new Date().toISOString()
      };
    }

    // Update the specific exercise
    dayProgress.exercises[exerciseId] = newProgress;
    dayProgress.lastUpdated = new Date().toISOString();
    dayProgress.levelTitle = levelTitle;
    dayProgress.dayName = dayName;

    // Save to localStorage
    localStorage.setItem(STORAGE_KEY, JSON.stringify(dayProgress));

    // Show toast with animation
    if (isCompleted) {
      toast.success('¡Ejercicio completado! 🎉', {
        duration: 2000,
        position: 'top-center'
      });
      
      // Save each completed exercise as an individual training session
      const session = {
        nivel: levelTitle,
        dia_rutina: dayName,
        ejercicios_completados: 1,
        total_ejercicios: 1,
        duracion_minutos: 5, // Estimate 5 minutes per exercise
        calificacion_esfuerzo: 8,
        notas: `Ejercicio: ${exerciseId}`
      };
      
      console.log('Saving training session for completed exercise:', session);
      await saveTrainingSession(session);
      
      // Play completion sound
      try {
        const audio = new Audio('/complete-sound.mp3');
        audio.play().catch(() => {
          // Silent fail if audio not available
        });
      } catch (error) {
        // Silent fail
      }
    } else {
      toast.success(`✓ Serie ${seriesCompleted}/3 completada`, {
        duration: 1500,
        position: 'top-center'
      });
      
      // Play series completion sound
      try {
        const audio = new Audio('/series-complete.mp3');
        audio.play().catch(() => {
          // Silent fail if audio not available
        });
      } catch (error) {
        // Silent fail
      }
    }

    return newProgress;
  } catch (error) {
    console.error('Error saving series progress:', error);
    return createDefaultProgress(exerciseId);
  }
};

export const resetDayProgress = () => {
  try {
    localStorage.removeItem(STORAGE_KEY);
    toast.info('Progreso del día reiniciado');
  } catch (error) {
    console.error('Error resetting day progress:', error);
  }
};

export const getCurrentDayProgress = (): DayProgress | null => {
  try {
    const savedProgress = localStorage.getItem(STORAGE_KEY);
    if (!savedProgress) {
      return null;
    }
    return JSON.parse(savedProgress);
  } catch (error) {
    console.error('Error getting current day progress:', error);
    return null;
  }
};

const createDefaultProgress = (exerciseId: string): ExerciseSeriesProgress => {
  return {
    exerciseId,
    seriesCompleted: 0,
    totalSeries: 3,
    isCompleted: false,
    lastUpdated: new Date().toISOString()
  };
};

// Calculate overall day completion percentage
export const calculateDayCompletionPercentage = (exercises: any[]): number => {
  const allProgress = getAllSeriesProgress();
  let totalSeries = exercises.length * 3; // 3 series per exercise
  let completedSeries = 0;

  exercises.forEach(exercise => {
    const progress = allProgress[exercise.id];
    if (progress) {
      completedSeries += progress.seriesCompleted;
    }
  });

  return totalSeries > 0 ? Math.round((completedSeries / totalSeries) * 100) : 0;
};
