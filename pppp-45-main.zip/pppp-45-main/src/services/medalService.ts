
import { supabase } from '@/integrations/supabase/client'

export interface Medal {
  id: string
  tipo_medalla: string
  nombre: string
  descripcion: string
  icono: string
  activa: boolean
  fecha_obtenida_real: string
}

export const getUserMedals = async (): Promise<Medal[]> => {
  try {
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      // Para usuarios no autenticados, devolver array vacío o medallas mock
      return []
    }

    const { data, error } = await supabase
      .from('medallas')
      .select('*')
      .eq('user_id', user.id)
      .eq('activa', true)
      .order('fecha_obtenida_real', { ascending: false })

    if (error) {
      console.error('Error fetching medals:', error)
      return []
    }

    return data || []
  } catch (error) {
    console.error('Error in getUserMedals:', error)
    return []
  }
}

export const getAvailableMedals = async () => {
  try {
    const { data, error } = await supabase
      .from('tipos_medallas')
      .select('*')
      .order('criterio_valor', { ascending: true })

    if (error) {
      console.error('Error fetching available medals:', error)
      return []
    }

    return data || []
  } catch (error) {
    console.error('Error in getAvailableMedals:', error)
    return []
  }
}
