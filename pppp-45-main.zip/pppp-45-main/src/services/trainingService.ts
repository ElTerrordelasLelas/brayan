
import { supabase } from '@/integrations/supabase/client'
import { toast } from 'sonner'

export interface TrainingSession {
  id?: string
  user_id?: string
  fecha?: string
  nivel: string
  dia_rutina: string
  ejercicios_completados: number
  total_ejercicios: number
  duracion_minutos?: number
  calificacion_esfuerzo?: number
  notas?: string
}

export const saveTrainingSession = async (session: TrainingSession): Promise<boolean> => {
  try {
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      // Para usuarios no autenticados, guardar en localStorage
      const sessions = JSON.parse(localStorage.getItem('training_sessions') || '[]')
      const newSession = {
        ...session,
        id: `local_${Date.now()}_${Math.random()}`, // Make ID more unique
        fecha: new Date().toISOString(),
        user_id: 'guest'
      }
      sessions.push(newSession)
      localStorage.setItem('training_sessions', JSON.stringify(sessions))
      
      console.log('Training session saved to localStorage:', newSession)
      console.log('All sessions:', sessions)
      
      return true
    }

    const { error } = await supabase
      .from('sesiones_entrenamiento')
      .insert({
        user_id: user.id,
        ...session,
        fecha: new Date().toISOString()
      })

    if (error) {
      console.error('Error saving training session:', error)
      toast.error('Error al guardar la sesión')
      return false
    }

    // Verificar medallas después de guardar la sesión
    await checkAndAwardMedals(user.id)
    
    console.log('Training session saved to Supabase:', session)
    return true
  } catch (error) {
    console.error('Error in saveTrainingSession:', error)
    toast.error('Error al guardar la sesión')
    return false
  }
}

export const getUserTrainingSessions = async (): Promise<TrainingSession[]> => {
  try {
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      // Para usuarios no autenticados, obtener de localStorage
      const sessions = JSON.parse(localStorage.getItem('training_sessions') || '[]')
      console.log('Retrieved sessions from localStorage:', sessions)
      return sessions
    }

    const { data, error } = await supabase
      .from('sesiones_entrenamiento')
      .select('*')
      .eq('user_id', user.id)
      .order('fecha', { ascending: false })

    if (error) {
      console.error('Error fetching training sessions:', error)
      return []
    }

    console.log('Retrieved sessions from Supabase:', data)
    return data || []
  } catch (error) {
    console.error('Error in getUserTrainingSessions:', error)
    return []
  }
}

export const getWeeklyProgress = async () => {
  try {
    const sessions = await getUserTrainingSessions()
    const now = new Date()
    const weekStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay())
    weekStart.setHours(0, 0, 0, 0)
    
    console.log('All sessions for weekly progress:', sessions)
    console.log('Week start:', weekStart)
    
    const weekSessions = sessions.filter(session => {
      const sessionDate = new Date(session.fecha || '')
      const isInWeek = sessionDate >= weekStart
      console.log(`Session date: ${sessionDate}, In week: ${isInWeek}`)
      return isInWeek
    })

    console.log('Week sessions:', weekSessions)

    // Count unique days with exercises
    const uniqueDays = new Set()
    weekSessions.forEach(session => {
      const day = new Date(session.fecha || '').toDateString()
      uniqueDays.add(day)
    })

    const avgEffort = weekSessions.length > 0 
      ? weekSessions.reduce((sum, s) => sum + (s.calificacion_esfuerzo || 0), 0) / weekSessions.length
      : 0

    const totalExercises = weekSessions.reduce((sum, s) => sum + s.ejercicios_completados, 0)

    const result = {
      diasActivos: uniqueDays.size,
      diasInactivos: 7 - uniqueDays.size,
      intensidadPromedio: Math.round(avgEffort * 10) / 10,
      totalEjercicios: totalExercises,
      ejercicios: weekSessions
    }

    console.log('Weekly progress result:', result)
    return result
  } catch (error) {
    console.error('Error getting weekly progress:', error)
    return {
      diasActivos: 0,
      diasInactivos: 7,
      intensidadPromedio: 0,
      totalEjercicios: 0,
      ejercicios: []
    }
  }
}

const checkAndAwardMedals = async (userId: string) => {
  try {
    const { error } = await supabase.rpc('verificar_medallas_usuario', {
      usuario_id: userId
    })

    if (error) {
      console.error('Error checking medals:', error)
    }
  } catch (error) {
    console.error('Error in checkAndAwardMedals:', error)
  }
}
