
import { supabase } from '@/integrations/supabase/client'
import { toast } from 'sonner'

export interface UserLevel {
  nivel_seleccionado: string | null
  fecha_seleccion_nivel: string | null
}

export const saveSelectedLevel = async (levelIndex: number, levelTitle: string): Promise<boolean> => {
  try {
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      // Para usuarios no autenticados, guardar en localStorage como fallback
      localStorage.setItem('selected_level', JSON.stringify({ levelIndex, levelTitle, fecha: new Date().toISOString() }))
      toast.success('Nivel seleccionado (modo invitado)')
      return true
    }

    console.log('Saving level for user:', user.id, 'Level:', levelTitle)

    // Intentar insertar o actualizar el perfil del usuario
    const { data, error } = await supabase
      .from('profiles')
      .upsert({
        id: user.id,
        nivel_seleccionado: levelTitle,
        fecha_seleccion_nivel: new Date().toISOString(),
        email: user.email,
        nombre: user.user_metadata?.name || user.email?.split('@')[0] || 'Usuario'
      }, {
        onConflict: 'id'
      })

    if (error) {
      console.error('Error saving level:', error)
      // Fallback: guardar en localStorage si falla la base de datos
      localStorage.setItem('selected_level', JSON.stringify({ levelIndex, levelTitle, fecha: new Date().toISOString() }))
      toast.success('Nivel seleccionado (guardado localmente)')
      return true
    }

    console.log('Level saved successfully:', data)
    toast.success('Nivel guardado exitosamente')
    return true
  } catch (error) {
    console.error('Error in saveSelectedLevel:', error)
    // Fallback: guardar en localStorage
    localStorage.setItem('selected_level', JSON.stringify({ levelIndex, levelTitle, fecha: new Date().toISOString() }))
    toast.success('Nivel seleccionado (guardado localmente)')
    return true
  }
}

export const getUserLevel = async (): Promise<{ levelIndex: number; levelTitle: string } | null> => {
  try {
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) {
      // Para usuarios no autenticados, intentar recuperar de localStorage
      const stored = localStorage.getItem('selected_level')
      if (stored) {
        try {
          const parsed = JSON.parse(stored)
          return { levelIndex: parsed.levelIndex, levelTitle: parsed.levelTitle }
        } catch (e) {
          console.error('Error parsing stored level:', e)
        }
      }
      return null
    }

    console.log('Getting level for user:', user.id)

    const { data, error } = await supabase
      .from('profiles')
      .select('nivel_seleccionado')
      .eq('id', user.id)
      .maybeSingle()

    if (error) {
      console.error('Error fetching user level:', error)
      // Fallback: intentar recuperar de localStorage
      const stored = localStorage.getItem('selected_level')
      if (stored) {
        try {
          const parsed = JSON.parse(stored)
          return { levelIndex: parsed.levelIndex, levelTitle: parsed.levelTitle }
        } catch (e) {
          console.error('Error parsing stored level:', e)
        }
      }
      return null
    }

    if (!data || !data.nivel_seleccionado) {
      console.log('No level found for user')
      return null
    }

    // Mapear el título del nivel a su índice
    const levelMapping: { [key: string]: number } = {
      'Principiante': 0,
      'Intermedio': 1,
      'Avanzado': 2
    }

    const levelIndex = levelMapping[data.nivel_seleccionado] || 0
    console.log('User level found:', data.nivel_seleccionado, 'Index:', levelIndex)

    return {
      levelIndex,
      levelTitle: data.nivel_seleccionado
    }
  } catch (error) {
    console.error('Error in getUserLevel:', error)
    // Fallback: intentar recuperar de localStorage
    const stored = localStorage.getItem('selected_level')
    if (stored) {
      try {
        const parsed = JSON.parse(stored)
        return { levelIndex: parsed.levelIndex, levelTitle: parsed.levelTitle }
      } catch (e) {
        console.error('Error parsing stored level:', e)
      }
    }
    return null
  }
}
