import React, { useState, useRef, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Dumbbell, Calendar, Users, Flame, Menu, X, ChevronRight, User, Lock, LogOut, HelpCircle, Shuffle, Edit } from 'lucide-react';
import { cn } from '@/lib/utils';
import GoldenButton from './GoldenButton';
import LoginModal from './LoginModal';
import ProfileEditModal from './ProfileEditModal';
import FAQModal from './FAQModal';
import QuickExerciseModal from './QuickExerciseModal';
import LevelTestModal from './LevelTestModal';
import { getCurrentUser, signOut, deleteAccount } from '../services/authService';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isFAQModalOpen, setIsFAQModalOpen] = useState(false);
  const [isQuickExerciseModalOpen, setIsQuickExerciseModalOpen] = useState(false);
  const [isLevelTestModalOpen, setIsLevelTestModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [userProfile, setUserProfile] = useState<any>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const sidebarRef = useRef<HTMLDivElement>(null);

  const menuItems = [
    { 
      title: 'AGENDAR HORA', 
      path: '/schedule', 
      icon: <Calendar className="w-5 h-5" strokeWidth={1.5} /> 
    },
    { 
      title: 'AGENDAR PERSONAL', 
      path: '/trainers', 
      icon: <Users className="w-5 h-5" strokeWidth={1.5} /> 
    },
    { 
      title: 'ENTRENAR', 
      path: '/level-selection', 
      icon: <Flame className="w-5 h-5" strokeWidth={1.5} /> 
    }
  ];

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  // Cerrar sidebar al hacer clic fuera
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (isMenuOpen && sidebarRef.current && !sidebarRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };

    if (isMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMenuOpen]);

  useEffect(() => {
    // Check auth state
    const checkAuth = async () => {
      const user = await getCurrentUser();
      setCurrentUser(user);
      
      if (user) {
        // Get user profile
        try {
          const { data } = await supabase
            .from('configuraciones_usuario')
            .select('*')
            .eq('user_id', user.id)
            .maybeSingle();
          setUserProfile(data);
        } catch (error) {
          console.log('Error fetching profile:', error);
        }
      }
    };

    checkAuth();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setCurrentUser(session?.user ?? null);
      if (event === 'SIGNED_OUT') {
        setUserProfile(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleSignOut = async () => {
    try {
      await signOut();
      setIsMenuOpen(false);
    } catch (error) {
      toast.error('Error al cerrar sesión');
    }
  };

  const handleDeleteAccount = async () => {
    if (window.confirm('¿Estás seguro de que quieres eliminar tu cuenta? Esta acción no se puede deshacer.')) {
      try {
        await deleteAccount();
        setIsMenuOpen(false);
      } catch (error) {
        toast.error('Error al eliminar la cuenta');
      }
    }
  };

  const handleLevelTestComplete = (level: number) => {
    setIsLevelTestModalOpen(false);
    navigate('/level-selection');
    toast.success(`Nivel ${level === 0 ? 'Principiante' : level === 1 ? 'Intermedio' : 'Avanzado'} asignado`);
  };

  return (
    <div className="min-h-screen flex flex-col bg-nova-black">
      {/* Header orgánico */}
      <header className="bg-gradient-to-r from-nova-black via-nova-darkGray/50 to-nova-black text-white p-6 flex justify-between items-center shadow-organic relative backdrop-blur-sm">
        <div className="absolute inset-x-0 top-0 h-[2px] bg-gradient-to-r from-transparent via-nova-red/50 to-transparent"></div>
        
        <div 
          className="flex items-center cursor-pointer group" 
          onClick={() => navigate('/')}
        >
          <div className="flex items-center justify-center h-12 w-12 nova-button-gradient rounded-nova mr-4 group-hover:scale-110 transition-transform duration-300">
            <Dumbbell className="h-7 w-7 text-white" strokeWidth={1.5} />
          </div>
          <h1 className="text-2xl font-nunito tracking-wide font-bold text-white uppercase">
            NOVA <span className="gradient-text">ERA</span>
          </h1>
        </div>
        
        <button 
          onClick={toggleMenu} 
          className="p-3 text-nova-red hover:bg-nova-red/10 rounded-nova transition-all duration-300 hover:scale-110"
        >
          <Menu strokeWidth={1.5} size={24} />
        </button>
      </header>

      <div className="flex flex-1 relative">
        {/* Overlay para móvil */}
        {isMenuOpen && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 transition-all duration-300" />
        )}

        {/* Sidebar orgánico */}
        {isMenuOpen && (
          <div 
            ref={sidebarRef}
            className="fixed left-0 top-0 h-full w-80 bg-gradient-to-b from-nova-black via-nova-darkGray/30 to-nova-black text-white z-50 shadow-organic transition-all duration-500 ease-out animate-slide-in-left rounded-r-nova-xl overflow-y-auto"
          >
            {/* Header del sidebar con logo */}
            <div className="p-generous border-b border-nova-red/20">
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center">
                  <div className="flex items-center justify-center h-12 w-12 nova-button-gradient rounded-nova mr-4">
                    <Dumbbell className="h-7 w-7 text-white" strokeWidth={1.5} />
                  </div>
                  <h1 className="text-xl font-nunito tracking-wider font-bold">
                    NOVA <span className="gradient-text">ERA</span>
                  </h1>
                </div>
                <button 
                  onClick={toggleMenu}
                  className="p-2 text-nova-red hover:bg-nova-red/10 rounded-nova transition-all duration-300"
                >
                  <X strokeWidth={1.5} size={20} />
                </button>
              </div>
              
              {/* Logo centrado con hover */}
              <div className="flex justify-center">
                <div className="flex items-center justify-center h-20 w-20 nova-button-gradient rounded-nova-xl shadow-glow transition-all duration-300 hover:scale-110 hover:shadow-xl cursor-pointer">
                  <Dumbbell className="h-12 w-12 text-white" strokeWidth={1.5} />
                </div>
              </div>
            </div>

            {/* Sección de usuario */}
            <div className="p-generous border-b border-nova-red/20">
              {currentUser ? (
                <div className="space-y-3">
                  <div className="text-center">
                    <p className="text-nova-gold text-sm">Bienvenido</p>
                    <p className="text-white font-semibold">{currentUser.email}</p>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => setIsProfileModalOpen(true)}
                      className="flex-1 py-2 px-3 bg-nova-darkGray/50 border border-nova-red/30 rounded-nova text-white text-sm hover:bg-nova-red/10 transition-all duration-300"
                    >
                      <Edit className="w-4 h-4 mx-auto" />
                    </button>
                    <button
                      onClick={handleSignOut}
                      className="flex-1 py-2 px-3 bg-nova-red/20 border border-nova-red/30 rounded-nova text-white text-sm hover:bg-nova-red/30 transition-all duration-300"
                    >
                      <LogOut className="w-4 h-4 mx-auto" />
                    </button>
                  </div>
                </div>
              ) : (
                <GoldenButton 
                  onClick={() => setIsLoginModalOpen(true)}
                  className="w-full text-sm py-3"
                  variant="red"
                >
                  INICIAR SESIÓN
                </GoldenButton>
              )}
            </div>

            {/* Navegación */}
            <div className="p-generous border-b border-nova-red/20">
              <h4 className="text-nova-gold font-nunito font-semibold mb-4 text-sm tracking-wider opacity-80">
                NAVEGACIÓN
              </h4>
              <ul className="space-y-3">
                {menuItems.map((item) => (
                  <li key={item.path}>
                    <button
                      onClick={() => {
                        navigate(item.path);
                        setIsMenuOpen(false);
                      }}
                      className={cn(
                        "w-full flex items-center px-5 py-4 transition-all duration-300 rounded-nova group",
                        "font-nunito font-medium tracking-wide hover:scale-105",
                        location.pathname === item.path 
                          ? "bg-gradient-to-r from-nova-red/20 to-nova-red/10 text-nova-gold shadow-glow border-l-4 border-nova-red" 
                          : "hover:bg-nova-darkGray/40 hover:shadow-soft"
                      )}
                    >
                      <span className="mr-4 group-hover:scale-110 transition-transform duration-300">
                        {item.icon}
                      </span>
                      <span className="flex-1 text-left text-sm">{item.title}</span>
                      <ChevronRight className="ml-auto h-4 w-4 opacity-60 group-hover:opacity-100 group-hover:translate-x-1 transition-all duration-300" strokeWidth={1.5} />
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Acciones rápidas */}
            <div className="p-generous border-b border-nova-red/20">
              <h4 className="text-nova-gold font-nunito font-semibold mb-4 text-sm tracking-wider opacity-80">
                ACCIONES RÁPIDAS
              </h4>
              <div className="space-y-3">
                <button
                  onClick={() => setIsQuickExerciseModalOpen(true)}
                  className="w-full flex items-center px-5 py-3 bg-nova-darkGray/40 hover:bg-nova-red/10 rounded-nova transition-all duration-300 text-sm"
                >
                  <Shuffle className="w-4 h-4 mr-3" />
                  Ejercicio Rápido
                </button>
                <button
                  onClick={() => setIsLevelTestModalOpen(true)}
                  className="w-full flex items-center px-5 py-3 bg-nova-darkGray/40 hover:bg-nova-red/10 rounded-nova transition-all duration-300 text-sm"
                >
                  <User className="w-4 h-4 mr-3" />
                  Test de Nivel
                </button>
                <button
                  onClick={() => setIsFAQModalOpen(true)}
                  className="w-full flex items-center px-5 py-3 bg-nova-darkGray/40 hover:bg-nova-red/10 rounded-nova transition-all duration-300 text-sm"
                >
                  <HelpCircle className="w-4 h-4 mr-3" />
                  Preguntas Frecuentes
                </button>
              </div>
            </div>

            {/* Opciones de cuenta */}
            {currentUser && (
              <div className="p-generous">
                <h4 className="text-nova-gold font-nunito font-semibold mb-4 text-sm tracking-wider opacity-80">
                  CUENTA
                </h4>
                <button
                  onClick={handleDeleteAccount}
                  className="w-full flex items-center px-5 py-3 bg-red-900/20 hover:bg-red-900/30 rounded-nova transition-all duration-300 text-sm text-red-400 hover:text-red-300"
                >
                  <X className="w-4 h-4 mr-3" />
                  Eliminar Cuenta
                </button>
              </div>
            )}
            
            {/* Footer del sidebar */}
            <div className="p-generous border-t border-nova-red/20 mt-auto">
              <div className="organic-divider mb-4"></div>
              <div className="text-center text-nova-gold text-xs font-nunito font-light tracking-wider opacity-80">
                ENTRENAMIENTO DE ÉLITE
              </div>
            </div>
          </div>
        )}

        {/* Contenido principal */}
        <main className="flex-1 bg-nova-black">
          {children}
        </main>
      </div>

      {/* Modales */}
      <LoginModal 
        isOpen={isLoginModalOpen} 
        onClose={() => setIsLoginModalOpen(false)} 
      />
      
      <ProfileEditModal 
        isOpen={isProfileModalOpen} 
        onClose={() => setIsProfileModalOpen(false)}
        currentProfile={userProfile}
      />
      
      <FAQModal 
        isOpen={isFAQModalOpen} 
        onClose={() => setIsFAQModalOpen(false)} 
      />
      
      <QuickExerciseModal 
        isOpen={isQuickExerciseModalOpen} 
        onClose={() => setIsQuickExerciseModalOpen(false)} 
      />
      
      <LevelTestModal 
        isOpen={isLevelTestModalOpen} 
        onClose={() => setIsLevelTestModalOpen(false)}
        onComplete={handleLevelTestComplete}
      />
    </div>
  );
};

export default Layout;
