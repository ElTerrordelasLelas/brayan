
import React, { useState } from 'react';
import { X, User, Weight } from 'lucide-react';
import GoldenButton from './GoldenButton';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface ProfileEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProfile?: {
    peso_corporal?: number;
    altura?: number;
  };
}

const ProfileEditModal: React.FC<ProfileEditModalProps> = ({ isOpen, onClose, currentProfile }) => {
  const [formData, setFormData] = useState({
    peso: currentProfile?.peso_corporal?.toString() || '',
    altura: currentProfile?.altura?.toString() || ''
  });

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        // Para usuarios no autenticados, guardar en localStorage
        localStorage.setItem('user_profile', JSON.stringify({
          peso: parseFloat(formData.peso),
          altura: parseInt(formData.altura)
        }));
        toast.success('Perfil actualizado (modo invitado)');
        onClose();
        return;
      }

      const { error } = await supabase
        .from('configuraciones_usuario')
        .upsert({
          user_id: user.id,
          peso_corporal: parseFloat(formData.peso) || null,
          altura: parseInt(formData.altura) || null,
          fecha_actualizacion: new Date().toISOString()
        }, {
          onConflict: 'user_id'
        });

      if (error) {
        console.error('Error updating profile:', error);
        toast.error('Error al actualizar el perfil');
        return;
      }

      toast.success('Perfil actualizado exitosamente');
      onClose();
    } catch (error) {
      console.error('Error in handleSubmit:', error);
      toast.error('Error al actualizar el perfil');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-b from-nova-black via-nova-darkGray/30 to-nova-black rounded-nova-xl p-8 w-full max-w-md relative shadow-organic border border-nova-red/20">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-nova-red hover:bg-nova-red/10 rounded-nova transition-all duration-300"
        >
          <X strokeWidth={1.5} size={20} />
        </button>

        <div className="text-center mb-8">
          <div className="flex items-center justify-center h-16 w-16 nova-button-gradient rounded-nova-xl mx-auto mb-4">
            <User className="h-8 w-8 text-white" strokeWidth={1.5} />
          </div>
          <h2 className="text-2xl font-nunito font-bold text-white mb-2">
            EDITAR PERFIL
          </h2>
          <p className="text-nova-gold text-sm opacity-80">
            Actualiza tu información personal
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 mb-6">
          <div className="relative">
            <Weight className="absolute left-3 top-1/2 transform -translate-y-1/2 text-nova-gold w-4 h-4" strokeWidth={1.5} />
            <input
              type="number"
              placeholder="Peso (kg)"
              value={formData.peso}
              onChange={(e) => setFormData({...formData, peso: e.target.value})}
              className="w-full pl-10 pr-4 py-3 bg-nova-darkGray/50 border border-nova-red/30 rounded-nova text-white placeholder-nova-lightGray/70 focus:outline-none focus:border-nova-red focus:ring-2 focus:ring-nova-red/20 transition-all duration-300 font-nunito"
              step="0.1"
              min="30"
              max="300"
            />
          </div>
          
          <div className="relative">
            <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-nova-gold w-4 h-4" strokeWidth={1.5} />
            <input
              type="number"
              placeholder="Altura (cm)"
              value={formData.altura}
              onChange={(e) => setFormData({...formData, altura: e.target.value})}
              className="w-full pl-10 pr-4 py-3 bg-nova-darkGray/50 border border-nova-red/30 rounded-nova text-white placeholder-nova-lightGray/70 focus:outline-none focus:border-nova-red focus:ring-2 focus:ring-nova-red/20 transition-all duration-300 font-nunito"
              min="140"
              max="220"
            />
          </div>

          <GoldenButton 
            type="submit"
            className="w-full py-3"
            variant="red"
          >
            GUARDAR CAMBIOS
          </GoldenButton>
        </form>
      </div>
    </div>
  );
};

export default ProfileEditModal;
