
import React, { useState } from 'react';
import { X, CheckCircle } from 'lucide-react';
import GoldenButton from './GoldenButton';
import { toast } from 'sonner';

interface LevelTestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: (level: number) => void;
}

const questions = [
  {
    question: "¿Con qué frecuencia haces ejercicio?",
    options: [
      { text: "Nunca o casi nunca", points: 0 },
      { text: "1-2 veces por semana", points: 1 },
      { text: "3-4 veces por semana", points: 2 },
      { text: "5+ veces por semana", points: 3 }
    ]
  },
  {
    question: "¿Cuánto tiempo llevas entrenando?",
    options: [
      { text: "Soy principiante", points: 0 },
      { text: "Menos de 6 meses", points: 1 },
      { text: "6 meses - 2 años", points: 2 },
      { text: "Más de 2 años", points: 3 }
    ]
  },
  {
    question: "¿Puedes hacer 20 flexiones seguidas?",
    options: [
      { text: "No puedo hacer ninguna", points: 0 },
      { text: "Puedo hacer 1-10", points: 1 },
      { text: "Puedo hacer 11-20", points: 2 },
      { text: "Puedo hacer más de 20", points: 3 }
    ]
  },
  {
    question: "¿Cuál es tu objetivo principal?",
    options: [
      { text: "Empezar a hacer ejercicio", points: 0 },
      { text: "Perder peso", points: 1 },
      { text: "Ganar músculo", points: 2 },
      { text: "Mejorar rendimiento", points: 3 }
    ]
  },
  {
    question: "¿Cómo te sientes después de subir 3 pisos?",
    options: [
      { text: "Muy cansado/a", points: 0 },
      { text: "Un poco cansado/a", points: 1 },
      { text: "Normal", points: 2 },
      { text: "Sin problemas", points: 3 }
    ]
  }
];

const LevelTestModal: React.FC<LevelTestModalProps> = ({ isOpen, onClose, onComplete }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);

  if (!isOpen) return null;

  const handleAnswer = () => {
    if (selectedOption === null) return;

    const newAnswers = [...answers, selectedOption];
    setAnswers(newAnswers);
    setSelectedOption(null);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      // Calcular nivel basado en puntuación total
      const totalPoints = newAnswers.reduce((sum, points) => sum + points, 0);
      let level = 0; // Principiante por defecto
      
      if (totalPoints >= 10) {
        level = 2; // Avanzado
      } else if (totalPoints >= 5) {
        level = 1; // Intermedio
      }

      toast.success('Test completado! Nivel asignado.');
      onComplete(level);
      
      // Reset para próxima vez
      setCurrentQuestion(0);
      setAnswers([]);
    }
  };

  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-b from-nova-black via-nova-darkGray/30 to-nova-black rounded-nova-xl p-8 w-full max-w-lg relative shadow-organic border border-nova-red/20">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-nova-red hover:bg-nova-red/10 rounded-nova transition-all duration-300"
        >
          <X strokeWidth={1.5} size={20} />
        </button>

        <div className="text-center mb-8">
          <div className="flex items-center justify-center h-16 w-16 nova-button-gradient rounded-nova-xl mx-auto mb-4">
            <CheckCircle className="h-8 w-8 text-white" strokeWidth={1.5} />
          </div>
          <h2 className="text-2xl font-nunito font-bold text-white mb-2">
            TEST DE NIVEL
          </h2>
          <p className="text-nova-gold text-sm opacity-80">
            Pregunta {currentQuestion + 1} de {questions.length}
          </p>
          
          {/* Barra de progreso */}
          <div className="w-full bg-nova-darkGray rounded-full h-2 mt-4">
            <div 
              className="bg-gradient-to-r from-nova-red to-nova-gold h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>

        <div className="mb-6">
          <h3 className="text-xl font-nunito font-semibold text-white mb-6 text-center">
            {questions[currentQuestion].question}
          </h3>
          
          <div className="space-y-3">
            {questions[currentQuestion].options.map((option, index) => (
              <button
                key={index}
                onClick={() => setSelectedOption(option.points)}
                className={`w-full p-4 rounded-nova text-left transition-all duration-300 ${
                  selectedOption === option.points
                    ? 'bg-nova-red/20 border-nova-red text-white'
                    : 'bg-nova-darkGray/50 border-nova-red/30 text-nova-lightGray hover:bg-nova-red/10'
                } border`}
              >
                {option.text}
              </button>
            ))}
          </div>
        </div>

        <GoldenButton 
          onClick={handleAnswer}
          disabled={selectedOption === null}
          className="w-full py-3"
          variant="red"
        >
          {currentQuestion < questions.length - 1 ? 'SIGUIENTE' : 'FINALIZAR TEST'}
        </GoldenButton>
      </div>
    </div>
  );
};

export default LevelTestModal;
