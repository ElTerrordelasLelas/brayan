
import React from 'react';
import { cn } from '@/lib/utils';

interface LevelCardProps {
  title: string;
  emoji: string;
  description: string;
  onClick: () => void;
  className?: string;
}

const LevelCard: React.FC<LevelCardProps> = ({ 
  title, 
  emoji, 
  description, 
  onClick, 
  className = "" 
}) => {
  const isDisabled = className.includes('cursor-not-allowed');

  return (
    <div 
      onClick={isDisabled ? undefined : onClick}
      className={cn(
        'flex flex-col items-center justify-center p-8 rounded-nova-lg',
        'nova-card floating-card text-white text-shadow-soft',
        'group relative overflow-hidden transition-all duration-300',
        isDisabled 
          ? 'cursor-not-allowed opacity-50' 
          : 'cursor-pointer hover:scale-105 hover:shadow-glow',
        className
      )}
    >
      <div className={cn(
        "text-5xl mb-6 transition-all duration-300",
        !isDisabled && "group-hover:animate-soft-pulse"
      )}>
        {emoji}
      </div>
      <h3 className={cn(
        "font-nunito font-bold text-2xl mb-4 text-center transition-colors duration-300",
        !isDisabled && "group-hover:text-nova-gold"
      )}>
        {title}
      </h3>
      <p className="text-nova-lightGray font-light text-center leading-relaxed">
        {description}
      </p>
      
      {/* Efecto de brillo sutil al hacer hover */}
      {!isDisabled && (
        <div className="absolute inset-0 rounded-nova-lg bg-gradient-to-br from-nova-gold/10 via-transparent to-nova-red/10 opacity-0 group-hover:opacity-100 transition-all duration-500"></div>
      )}
    </div>
  );
};

export default LevelCard;
