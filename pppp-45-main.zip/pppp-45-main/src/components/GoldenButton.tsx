
import React from 'react';
import { cn } from '@/lib/utils';

interface GoldenButtonProps {
  onClick?: () => void;
  children: React.ReactNode;
  className?: string;
  fullWidth?: boolean;
  variant?: 'red' | 'gold';
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset';
}

const GoldenButton: React.FC<GoldenButtonProps> = ({ 
  onClick, 
  children, 
  className = "",
  fullWidth = false,
  variant = 'red',
  disabled = false,
  type = 'button'
}) => {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        'relative px-8 py-4 border font-nunito font-semibold uppercase tracking-wider',
        'text-white text-shadow-soft shadow-organic',
        'button-organic rounded-nova',
        'transform-gpu will-change-transform',
        'transition-all duration-500 ease-[cubic-bezier(0.34,1.56,0.64,1)]',
        variant === 'red' ? 'nova-button-gradient border-nova-red/30' : 'nova-gold-gradient border-nova-gold/30',
        fullWidth ? 'w-full' : '',
        disabled ? 'opacity-50 cursor-not-allowed hover:scale-100 hover:shadow-soft' : 'hover:scale-110 hover:shadow-glow active:scale-95',
        className
      )}
    >
      <div className="relative z-10 flex items-center justify-center gap-2 transition-all duration-300">
        {children}
      </div>
      <div className="absolute inset-0 rounded-nova bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 hover:opacity-100 transition-all duration-500 ease-out"></div>
    </button>
  );
};

export default GoldenButton;
