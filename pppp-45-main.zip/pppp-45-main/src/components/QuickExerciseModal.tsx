
import React, { useState } from 'react';
import { X, Shuffle, Play } from 'lucide-react';
import GoldenButton from './GoldenButton';
import workoutLevels from '../data/workoutRoutines';
import { useNavigate } from 'react-router-dom';

interface QuickExerciseModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const QuickExerciseModal: React.FC<QuickExerciseModalProps> = ({ isOpen, onClose }) => {
  const [randomExercise, setRandomExercise] = useState<any>(null);
  const navigate = useNavigate();

  if (!isOpen) return null;

  const generateRandomExercise = () => {
    // Obtener todos los ejercicios de todos los niveles
    const allExercises: any[] = [];
    workoutLevels.forEach(level => {
      level.days.forEach(day => {
        allExercises.push(...day.exercises);
      });
    });

    // Seleccionar ejercicio aleatorio
    const randomIndex = Math.floor(Math.random() * allExercises.length);
    setRandomExercise(allExercises[randomIndex]);
  };

  const startQuickExercise = () => {
    if (randomExercise) {
      onClose();
      navigate(`/exercise/${randomExercise.id}`);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-b from-nova-black via-nova-darkGray/30 to-nova-black rounded-nova-xl p-8 w-full max-w-md relative shadow-organic border border-nova-red/20">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-nova-red hover:bg-nova-red/10 rounded-nova transition-all duration-300"
        >
          <X strokeWidth={1.5} size={20} />
        </button>

        <div className="text-center mb-8">
          <div className="flex items-center justify-center h-16 w-16 nova-button-gradient rounded-nova-xl mx-auto mb-4">
            <Shuffle className="h-8 w-8 text-white" strokeWidth={1.5} />
          </div>
          <h2 className="text-2xl font-nunito font-bold text-white mb-2">
            EJERCICIO RÁPIDO
          </h2>
          <p className="text-nova-gold text-sm opacity-80">
            Prueba un ejercicio aleatorio
          </p>
        </div>

        {!randomExercise ? (
          <div className="text-center">
            <p className="text-white mb-6">
              Genera un ejercicio aleatorio para entrenar rápidamente
            </p>
            <GoldenButton 
              onClick={generateRandomExercise}
              className="w-full py-3"
              variant="red"
            >
              <Shuffle className="w-5 h-5 mr-2" />
              GENERAR EJERCICIO
            </GoldenButton>
          </div>
        ) : (
          <div className="text-center">
            <div className="bg-white/10 rounded-nova p-6 mb-6">
              <img 
                src={randomExercise.image} 
                alt={randomExercise.name}
                className="w-full h-32 object-cover rounded-nova mb-4"
              />
              <h3 className="text-xl font-nunito font-bold text-white mb-2">
                {randomExercise.name}
              </h3>
              <p className="text-nova-gold text-sm mb-2">
                {randomExercise.reps}
              </p>
              <p className="text-white/80 text-sm">
                {randomExercise.muscleGroups}
              </p>
            </div>
            
            <div className="space-y-3">
              <GoldenButton 
                onClick={startQuickExercise}
                className="w-full py-3"
                variant="red"
              >
                <Play className="w-5 h-5 mr-2" />
                COMENZAR EJERCICIO
              </GoldenButton>
              
              <button
                onClick={generateRandomExercise}
                className="w-full py-3 px-4 bg-nova-darkGray/50 border border-nova-red/30 rounded-nova text-white hover:bg-nova-red/10 transition-all duration-300"
              >
                <Shuffle className="w-5 h-5 mr-2 inline" />
                OTRO EJERCICIO
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default QuickExerciseModal;
