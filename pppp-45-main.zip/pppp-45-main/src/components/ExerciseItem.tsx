
import React from 'react';
import { Play, CheckCircle } from 'lucide-react';

interface ExerciseItemProps {
  name: string;
  reps: string;
  imageUrl?: string;
  isPopular?: boolean;
  equipment?: string;
  onClick: () => void;
  seriesCompleted?: number;
  totalSeries?: number;
  isCompleted?: boolean;
}

const ExerciseItem: React.FC<ExerciseItemProps> = ({ 
  name, 
  reps, 
  imageUrl, 
  isPopular = false, 
  equipment,
  onClick,
  seriesCompleted = 0,
  totalSeries = 3,
  isCompleted = false
}) => {
  return (
    <div 
      className={`nova-card p-4 cursor-pointer floating-card transition-all duration-300 ${
        isCompleted ? 'opacity-80 bg-green-900/20 border border-green-500/30' : ''
      }`}
      onClick={onClick}
    >
      <div className="flex items-center space-x-4">
        {/* Exercise Image */}
        <div className="w-16 h-16 rounded-nova overflow-hidden bg-nova-darkGray/40 flex-shrink-0">
          {imageUrl ? (
            <img 
              src={imageUrl} 
              alt={name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Play className="w-6 h-6 text-nova-gold" />
            </div>
          )}
        </div>
        
        {/* Exercise Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2 mb-1">
            <h3 className="font-nunito font-bold text-white text-sm truncate">
              {name}
            </h3>
            {isPopular && (
              <span className="bg-nova-red text-white text-xs px-2 py-1 rounded-nova flex-shrink-0">
                Popular
              </span>
            )}
            {isCompleted && (
              <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
            )}
          </div>
          <p className="text-nova-lightGray text-xs mb-1">{reps}</p>
          {equipment && (
            <p className="text-nova-gold text-xs mb-1">
              Equipo: {equipment}
            </p>
          )}
          
          {/* Series Progress */}
          <div className="flex items-center space-x-2 mt-2">
            <span className="text-xs text-nova-lightGray">Series:</span>
            <div className="flex space-x-1">
              {Array.from({ length: totalSeries }, (_, index) => (
                <div
                  key={index}
                  className={`w-3 h-3 rounded-full border transition-all duration-300 ${
                    index < seriesCompleted
                      ? 'bg-green-500 border-green-500'
                      : 'border-nova-lightGray/40'
                  }`}
                />
              ))}
            </div>
            <span className="text-xs text-nova-gold">
              {seriesCompleted}/{totalSeries}
            </span>
          </div>
        </div>
        
        {/* Arrow indicator */}
        <div className="text-nova-lightGray">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </div>
    </div>
  );
};

export default ExerciseItem;
