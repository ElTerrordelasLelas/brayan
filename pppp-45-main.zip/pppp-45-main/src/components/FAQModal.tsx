
import React from 'react';
import { X, HelpCircle } from 'lucide-react';

interface FAQModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const faqs = [
  {
    question: "¿Cómo selecciono mi nivel de entrenamiento?",
    answer: "Puedes hacer el test de nivel desde tu perfil o seleccionar manualmente el nivel que mejor se ajuste a tu experiencia."
  },
  {
    question: "¿Puedo cambiar mi rutina una vez seleccionada?",
    answer: "Sí, puedes cambiar tu nivel en cualquier momento desde la pantalla de selección de nivel."
  },
  {
    question: "¿Cómo funciona el sistema de medallas?",
    answer: "Las medallas se otorgan automáticamente al completar ciertos logros como entrenar varios días seguidos o completar un número específico de sesiones."
  },
  {
    question: "¿Puedo usar la app sin internet?",
    answer: "Sí, la aplicación guarda tu progreso localmente y se sincroniza cuando vuelves a tener conexión."
  },
  {
    question: "¿Cómo ajusto la intensidad de los ejercicios?",
    answer: "En cada ejercicio puedes ajustar la intensidad del 1 al 5 usando el control deslizante."
  },
  {
    question: "¿Qué pasa si no completo un ejercicio?",
    answer: "No hay problema, puedes marcar los ejercicios como completados solo cuando los hayas terminado realmente."
  }
];

const FAQModal: React.FC<FAQModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-b from-nova-black via-nova-darkGray/30 to-nova-black rounded-nova-xl p-8 w-full max-w-2xl relative shadow-organic border border-nova-red/20 max-h-[80vh] overflow-y-auto">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-nova-red hover:bg-nova-red/10 rounded-nova transition-all duration-300"
        >
          <X strokeWidth={1.5} size={20} />
        </button>

        <div className="text-center mb-8">
          <div className="flex items-center justify-center h-16 w-16 nova-button-gradient rounded-nova-xl mx-auto mb-4">
            <HelpCircle className="h-8 w-8 text-white" strokeWidth={1.5} />
          </div>
          <h2 className="text-2xl font-nunito font-bold text-white mb-2">
            PREGUNTAS FRECUENTES
          </h2>
          <p className="text-nova-gold text-sm opacity-80">
            Encuentra respuestas a las dudas más comunes
          </p>
        </div>

        <div className="space-y-6">
          {faqs.map((faq, index) => (
            <div key={index} className="bg-white/5 rounded-nova p-6">
              <h3 className="text-lg font-nunito font-semibold text-nova-gold mb-3">
                {faq.question}
              </h3>
              <p className="text-white/90 leading-relaxed">
                {faq.answer}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FAQModal;
