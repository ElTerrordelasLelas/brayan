import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Clock, Star, Calendar, User, X, ChevronLeft } from 'lucide-react';
import GoldenButton from '../components/GoldenButton';
import { cn } from '@/lib/utils';

interface Trainer {
  id: number;
  name: string;
  specialty: string;
  image: string;
  rating: number;
  available: boolean;
  availability: {
    [day: string]: {
      start: string;
      end: string;
    }[];
  };
}

const mockTrainers: Trainer[] = [
  {
    id: 1,
    name: 'Alice Johnson',
    specialty: 'Yoga & Pilates',
    image: 'https://images.unsplash.com/photo-1571593014359-4a5986d44941?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80',
    rating: 4.8,
    available: true,
    availability: {
      Monday: [{ start: '9:00', end: '17:00' }],
      Tuesday: [{ start: '10:00', end: '16:00' }],
      Wednesday: [],
      Thursday: [{ start: '9:00', end: '17:00' }],
      Friday: [{ start: '10:00', end: '16:00' }],
      Saturday: [],
      Sunday: []
    }
  },
  {
    id: 2,
    name: 'Bob Williams',
    specialty: 'Strength Training',
    image: 'https://images.unsplash.com/photo-1540496978429-59791c582043?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    rating: 4.5,
    available: true,
    availability: {
      Monday: [{ start: '14:00', end: '20:00' }],
      Tuesday: [],
      Wednesday: [{ start: '14:00', end: '20:00' }],
      Thursday: [],
      Friday: [{ start: '14:00', end: '20:00' }],
      Saturday: [{ start: '10:00', end: '14:00' }],
      Sunday: []
    }
  },
  {
    id: 3,
    name: 'Charlie Brown',
    specialty: 'Cardio & HIIT',
    image: 'https://images.unsplash.com/photo-1583454110551-451573c95168?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80',
    rating: 4.2,
    available: false,
    availability: {
      Monday: [],
      Tuesday: [{ start: '8:00', end: '12:00' }],
      Wednesday: [],
      Thursday: [{ start: '8:00', end: '12:00' }],
      Friday: [],
      Saturday: [{ start: '14:00', end: '18:00' }],
      Sunday: []
    }
  },
  {
    id: 4,
    name: 'Diana Miller',
    specialty: 'CrossFit',
    image: 'https://images.unsplash.com/photo-1518310333737-5f3bf884929c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    rating: 4.9,
    available: true,
    availability: {
      Monday: [{ start: '16:00', end: '22:00' }],
      Tuesday: [{ start: '16:00', end: '22:00' }],
      Wednesday: [{ start: '16:00', end: '22:00' }],
      Thursday: [{ start: '16:00', end: '22:00' }],
      Friday: [{ start: '16:00', end: '22:00' }],
      Saturday: [],
      Sunday: []
    }
  },
  {
    id: 5,
    name: 'Ethan Davis',
    specialty: 'Calisthenics',
    image: 'https://images.unsplash.com/photo-1622287534704-799a1c41a941?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80',
    rating: 4.7,
    available: true,
    availability: {
      Monday: [],
      Tuesday: [{ start: '12:00', end: '18:00' }],
      Wednesday: [],
      Thursday: [{ start: '12:00', end: '18:00' }],
      Friday: [],
      Saturday: [{ start: '8:00', end: '12:00' }],
      Sunday: []
    }
  }
];

const TrainersScreen = () => {
  const navigate = useNavigate();
  const [selectedTrainer, setSelectedTrainer] = useState<Trainer | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = (trainer: Trainer) => {
    setSelectedTrainer(trainer);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setSelectedTrainer(null);
    setIsModalOpen(false);
  };

  return (
    <div className="min-h-screen bg-nova-black text-white p-8">
      {/* Encabezado con botón de retroceso */}
      <div className="mb-8 flex items-center">
        <button onClick={() => navigate(-1)} className="mr-4 p-2 rounded-full hover:bg-nova-red/10 transition-colors">
          <ChevronLeft strokeWidth={2} size={24} />
        </button>
        <h1 className="text-3xl font-bold font-nunito uppercase tracking-wider">Nuestros Entrenadores</h1>
      </div>

      {/* Listado de entrenadores */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mockTrainers.map((trainer) => (
          <div key={trainer.id} className="rounded-nova-lg overflow-hidden shadow-md nova-card hover:scale-105 transition-transform duration-300">
            <img src={trainer.image} alt={trainer.name} className="w-full h-48 object-cover" />
            <div className="p-4">
              <h2 className="text-xl font-semibold mb-2">{trainer.name}</h2>
              <p className="text-nova-gold mb-2">{trainer.specialty}</p>
              <div className="flex items-center mb-2">
                <Star className="text-yellow-500 mr-1" size={16} />
                <span>{trainer.rating}</span>
              </div>
              <GoldenButton onClick={() => openModal(trainer)} className="w-full" variant="gold">
                Ver Disponibilidad
              </GoldenButton>
            </div>
          </div>
        ))}
      </div>

      {/* Modal de disponibilidad */}
      {isModalOpen && selectedTrainer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="bg-nova-darkGray rounded-nova-lg p-8 max-w-md w-full relative">
            {/* Botón de cerrar */}
            <button onClick={closeModal} className="absolute top-4 right-4 p-2 rounded-full hover:bg-nova-red/10 transition-colors">
              <X strokeWidth={2} size={20} />
            </button>

            <h2 className="text-2xl font-bold mb-4">{selectedTrainer.name}</h2>
            <p className="text-nova-gold mb-4">{selectedTrainer.specialty}</p>

            {/* Horario de disponibilidad */}
            <h3 className="text-lg font-semibold mb-2">Disponibilidad Semanal:</h3>
            <ul className="space-y-2">
              {Object.entries(selectedTrainer.availability).map(([day, times]) => (
                <li key={day} className="flex items-center justify-between">
                  <span>{day}:</span>
                  {times.length > 0 ? (
                    <span>
                      {times.map((time, index) => (
                        <span key={index}>
                          {time.start} - {time.end}
                          {index < times.length - 1 ? ', ' : ''}
                        </span>
                      ))}
                    </span>
                  ) : (
                    <span className="text-gray-500">No disponible</span>
                  )}
                </li>
              ))}
            </ul>

            {/* Botón para agendar (simulado) */}
            <div className="mt-6">
              <GoldenButton onClick={() => alert('Funcionalidad de agendar en desarrollo.')} className="w-full">
                Agendar Sesión
              </GoldenButton>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TrainersScreen;
