import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Moon, Sun, Flame, Target, TrendingUp, Award, Calendar } from 'lucide-react';
import GoldenButton from '../components/GoldenButton';
import { toast } from 'sonner';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, ComposedChart, Bar } from 'recharts';
import { getWeeklyProgress } from '../services/trainingService';

const motivationalPhrases = [
  "No hay atajos para un lugar al que vale la pena llegar.",
  "El mejor proyecto en el que puedes trabajar eres tú.",
  "Pequeños pasos, grandes resultados.",
  "La disciplina es el puente entre tus metas y tus logros.",
  "Tu cuerpo puede resistir casi cualquier cosa. Es tu mente la que debes convencer.",
];

const WeeklyProgressScreen: React.FC = () => {
  const navigate = useNavigate();
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [weeklyData, setWeeklyData] = useState<any[]>([]);
  const [progressStats, setProgressStats] = useState({
    diasActivos: 0,
    diasInactivos: 7,
    intensidadPromedio: 0,
    totalEjercicios: 0,
    totalCalorias: 0,
    promedioSueno: 7.6
  });
  const [achievements, setAchievements] = useState([
    { 
      id: 'streak', 
      title: '3 días seguidos', 
      icon: '🔥', 
      description: 'Racha de entrenamientos',
      progress: 0,
      unlocked: false
    },
    { 
      id: 'sleep', 
      title: 'Sueño de calidad', 
      icon: '🌙', 
      description: '8+ horas por 3 días',
      progress: 75,
      unlocked: true
    },
    { 
      id: 'calories', 
      title: 'Quemador de calorías', 
      icon: '💪', 
      description: '400+ calorías quemadas',
      progress: 60,
      unlocked: false
    },
    { 
      id: 'consistency', 
      title: 'Constancia', 
      icon: '⭐', 
      description: '5 entrenamientos semanales',
      progress: 0,
      unlocked: false
    },
  ]);

  // Load and process weekly data
  useEffect(() => {
    const loadWeeklyData = async () => {
      try {
        console.log('Loading weekly progress data...')
        const weeklyProgress = await getWeeklyProgress();
        console.log('Weekly progress loaded:', weeklyProgress)
        
        // Update progress stats
        setProgressStats({
          diasActivos: weeklyProgress.diasActivos,
          diasInactivos: weeklyProgress.diasInactivos,
          intensidadPromedio: weeklyProgress.intensidadPromedio,
          totalEjercicios: weeklyProgress.totalEjercicios,
          totalCalorias: weeklyProgress.totalEjercicios * 35, // Estimate calories
          promedioSueno: 7.6 // Mock data for sleep
        });

        // Process data for chart - group sessions by day
        const weekDays = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
        const chartData = weekDays.map((day, index) => {
          // Get all sessions for this day of the week
          const dayOfWeek = (index + 1) % 7; // Convert to JS day format (0=Sun, 1=Mon, etc.)
          const sessionsForDay = weeklyProgress.ejercicios.filter((session: any) => {
            const sessionDate = new Date(session.fecha);
            return sessionDate.getDay() === dayOfWeek;
          });

          const totalExercisesForDay = sessionsForDay.reduce((sum: number, session: any) => 
            sum + session.ejercicios_completados, 0);

          return {
            day,
            sleep: 7.5 + Math.random() * 1.5, // Mock sleep data
            calories: totalExercisesForDay * 35,
            workouts: sessionsForDay.length > 0 ? 1 : 0,
            exercises: totalExercisesForDay
          };
        });

        console.log('Chart data processed:', chartData)
        setWeeklyData(chartData);

        // Update achievements based on progress
        setAchievements(prev => prev.map(achievement => {
          switch (achievement.id) {
            case 'streak':
              return {
                ...achievement,
                progress: Math.min(100, (weeklyProgress.diasActivos / 3) * 100),
                unlocked: weeklyProgress.diasActivos >= 3
              };
            case 'consistency':
              return {
                ...achievement,
                progress: Math.min(100, (weeklyProgress.diasActivos / 5) * 100),
                unlocked: weeklyProgress.diasActivos >= 5
              };
            default:
              return achievement;
          }
        }));

      } catch (error) {
        console.error('Error loading weekly data:', error);
      }
    };

    loadWeeklyData();
  }, []); // Remove the interval refresh for now to avoid too many calls
  
  const handleBack = () => {
    navigate('/routine');
  };
  
  const toggleDarkMode = () => {
    setIsDarkMode(prev => !prev);
    document.documentElement.classList.toggle('dark');
  };
  
  // Handle shake gesture for easter egg
  useEffect(() => {
    let shakeThreshold = 15;
    let lastX: number | null = null;
    let lastY: number | null = null;
    let lastZ: number | null = null;
    let lastTime = 0;
    
    const handleMotion = (event: DeviceMotionEvent) => {
      const currentTime = new Date().getTime();
      if ((currentTime - lastTime) > 100) {
        const acceleration = event.accelerationIncludingGravity;
        
        if (!acceleration) return;
        
        let x = acceleration.x || 0;
        let y = acceleration.y || 0;
        let z = acceleration.z || 0;
        
        if (lastX !== null && lastY !== null && lastZ !== null) {
          const deltaX = Math.abs(x - lastX);
          const deltaY = Math.abs(y - lastY);
          const deltaZ = Math.abs(z - lastZ);
          
          if ((deltaX > shakeThreshold && deltaY > shakeThreshold) || 
              (deltaX > shakeThreshold && deltaZ > shakeThreshold) || 
              (deltaY > shakeThreshold && deltaZ > shakeThreshold)) {
            const randomPhrase = motivationalPhrases[Math.floor(Math.random() * motivationalPhrases.length)];
            toast.success(randomPhrase, { position: 'bottom-center', duration: 5000 });
          }
        }
        
        lastX = x;
        lastY = y;
        lastZ = z;
        lastTime = currentTime;
      }
    };
    
    if (window.DeviceMotionEvent) {
      window.addEventListener('devicemotion', handleMotion);
    }
    
    return () => {
      if (window.DeviceMotionEvent) {
        window.removeEventListener('devicemotion', handleMotion);
      }
    };
  }, []);

  return (
    <div className={`nova-gradient min-h-screen flex flex-col ${isDarkMode ? 'dark' : ''}`}>
      {/* Header */}
      <header className="pt-12 pb-6 px-6 flex items-center justify-between">
        <button onClick={handleBack} className="p-3 hover:bg-nova-red/10 rounded-nova transition-all duration-300">
          <ArrowLeft size={24} className="text-white" strokeWidth={1.5} />
        </button>
        <h1 className="flex-1 text-2xl font-nunito font-bold text-white text-center mx-4">
          Progreso <span className="gradient-text">Semanal</span>
        </h1>
        <button 
          onClick={toggleDarkMode}
          className="p-3 hover:bg-nova-red/10 rounded-nova transition-all duration-300"
        >
          {isDarkMode ? <Sun size={20} className="text-white" strokeWidth={1.5} /> : <Moon size={20} className="text-white" strokeWidth={1.5} />}
        </button>
      </header>
      
      {/* Métricas Principales */}
      <div className="px-6 mb-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="nova-card p-4 text-center">
            <div className="flex items-center justify-center h-12 w-12 nova-button-gradient rounded-nova mx-auto mb-3">
              <Moon className="h-6 w-6 text-white" strokeWidth={1.5} />
            </div>
            <h3 className="text-2xl font-nunito font-bold text-nova-gold">
              {progressStats.promedioSueno.toFixed(1)}h
            </h3>
            <p className="text-nova-lightGray text-sm">Sueño promedio</p>
          </div>
          
          <div className="nova-card p-4 text-center">
            <div className="flex items-center justify-center h-12 w-12 nova-button-gradient rounded-nova mx-auto mb-3">
              <Flame className="h-6 w-6 text-white" strokeWidth={1.5} />
            </div>
            <h3 className="text-2xl font-nunito font-bold text-nova-gold">
              {progressStats.totalCalorias.toLocaleString()}
            </h3>
            <p className="text-nova-lightGray text-sm">Calorías quemadas</p>
          </div>
          
          <div className="nova-card p-4 text-center">
            <div className="flex items-center justify-center h-12 w-12 nova-button-gradient rounded-nova mx-auto mb-3">
              <Target className="h-6 w-6 text-white" strokeWidth={1.5} />
            </div>
            <h3 className="text-2xl font-nunito font-bold text-nova-gold">
              {Math.round((progressStats.diasActivos / 7) * 100)}%
            </h3>
            <p className="text-nova-lightGray text-sm">Objetivos cumplidos</p>
          </div>
          
          <div className="nova-card p-4 text-center">
            <div className="flex items-center justify-center h-12 w-12 nova-button-gradient rounded-nova mx-auto mb-3">
              <TrendingUp className="h-6 w-6 text-white" strokeWidth={1.5} />
            </div>
            <h3 className="text-2xl font-nunito font-bold text-nova-gold">
              {progressStats.totalEjercicios}
            </h3>
            <p className="text-nova-lightGray text-sm">Ejercicios completados</p>
          </div>
        </div>
      </div>
      
      {/* Gráfico Combinado */}
      <div className="px-6 mb-8">
        <div className="nova-card p-6">
          <h2 className="font-nunito font-bold text-white mb-6 flex items-center">
            <Calendar className="mr-3 h-5 w-5 text-nova-gold" strokeWidth={1.5} />
            Actividad Semanal
          </h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={weeklyData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis 
                  dataKey="day" 
                  tick={{ fill: 'white', fontSize: 12 }}
                  axisLine={{ stroke: 'rgba(255,255,255,0.2)' }}
                />
                <YAxis 
                  yAxisId="left"
                  tick={{ fill: 'white', fontSize: 12 }}
                  axisLine={{ stroke: 'rgba(255,255,255,0.2)' }}
                />
                <YAxis 
                  yAxisId="right" 
                  orientation="right"
                  tick={{ fill: 'white', fontSize: 12 }}
                  axisLine={{ stroke: 'rgba(255,255,255,0.2)' }}
                />
                <Line 
                  yAxisId="left"
                  type="monotone" 
                  dataKey="sleep" 
                  stroke="#d4af37" 
                  strokeWidth={3}
                  dot={{ fill: '#d4af37', strokeWidth: 2, r: 4 }}
                  name="Horas de sueño"
                />
                <Bar 
                  yAxisId="right"
                  dataKey="exercises" 
                  fill="rgba(196, 18, 18, 0.6)"
                  name="Ejercicios completados"
                />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center mt-4 space-x-6">
            <div className="flex items-center">
              <div className="w-4 h-4 bg-nova-gold rounded mr-2"></div>
              <span className="text-nova-lightGray text-sm">Horas de sueño</span>
            </div>
            <div className="flex items-center">
              <div className="w-4 h-4 bg-nova-red/60 rounded mr-2"></div>
              <span className="text-nova-lightGray text-sm">Ejercicios completados</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Logros */}
      <div className="px-6 mb-8">
        <h2 className="font-nunito font-bold text-white mb-6 flex items-center">
          <Award className="mr-3 h-5 w-5 text-nova-gold" strokeWidth={1.5} />
          Tus Logros
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {achievements.map(achievement => (
            <div 
              key={achievement.id}
              className={`nova-card p-6 transition-all duration-300 ${achievement.unlocked ? 'floating-card cursor-pointer' : 'opacity-60'}`}
              onClick={() => achievement.unlocked && toast.success(`¡Desbloqueaste: ${achievement.title}!`)}
            >
              <div className="flex items-center mb-4">
                <div className={`w-12 h-12 rounded-nova flex items-center justify-center text-2xl mr-4 ${achievement.unlocked ? 'nova-button-gradient' : 'bg-nova-darkGray/40'}`}>
                  {achievement.icon}
                </div>
                <div className="flex-1">
                  <h3 className="font-nunito font-bold text-white">{achievement.title}</h3>
                  <p className="text-nova-lightGray text-sm">{achievement.description}</p>
                </div>
              </div>
              
              {/* Barra de progreso */}
              <div className="w-full bg-nova-darkGray/40 rounded-nova h-2 overflow-hidden">
                <div 
                  className={`h-full transition-all duration-500 ${achievement.unlocked ? 'nova-button-gradient' : 'bg-nova-gold/30'}`}
                  style={{ width: `${achievement.progress}%` }}
                ></div>
              </div>
              <div className="flex justify-between mt-2">
                <span className="text-nova-lightGray text-xs">Progreso</span>
                <span className="text-nova-gold text-xs font-medium">{Math.round(achievement.progress)}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Motivación */}
      <div className="px-6 mb-8">
        <div className="nova-card p-6 text-center">
          <h3 className="font-nunito font-bold text-nova-gold mb-4 text-lg">Mensaje del día</h3>
          <p className="text-white/90 italic text-lg leading-relaxed mb-4">
            "La consistencia es la clave del éxito. ¡Sigue así!"
          </p>
          <p className="text-nova-lightGray text-sm">
            <em>💡 Sacude tu dispositivo para más motivación</em>
          </p>
        </div>
      </div>
      
      {/* Botón de acción */}
      <div className="px-6 pb-8 mt-auto">
        <GoldenButton 
          onClick={handleBack}
          className="w-full py-4 text-lg"
        >
          <ArrowLeft className="w-5 h-5 mr-2" strokeWidth={1.5} />
          Volver a mi rutina
        </GoldenButton>
      </div>
    </div>
  );
};

export default WeeklyProgressScreen;
