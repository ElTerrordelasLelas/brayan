import React, { useState, useRef, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Play, Pause, Info, CheckCircle } from 'lucide-react';
import IntensitySlider from '../components/IntensitySlider';
import GoldenButton from '../components/GoldenButton';
import ExerciseTimer from '../components/ExerciseTimer';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { toast } from 'sonner';
import { Exercise } from '../data/workoutRoutines';
import workoutLevels from '../data/workoutRoutines';
import { getSeriesProgress, saveSeriesProgress } from '../services/seriesService';

const ExerciseDetailScreen: React.FC = () => {
  const navigate = useNavigate();
  const { exerciseId } = useParams<{ exerciseId: string }>();
  const [isPlaying, setIsPlaying] = useState(false);
  const [intensity, setIntensity] = useState(5);
  const [showWaveEffect, setShowWaveEffect] = useState(false);
  const [isImageLoading, setIsImageLoading] = useState(true);
  const [reps, setReps] = useState('');
  const [timerDuration, setTimerDuration] = useState(60);
  const [seriesCompleted, setSeriesCompleted] = useState(0);
  const touchStartX = useRef<number | null>(null);
  
  const findExercise = (): Exercise | undefined => {
    for (const level of workoutLevels) {
      for (const day of level.days) {
        const found = day.exercises.find(ex => ex.id === exerciseId);
        if (found) return found;
      }
    }
    return undefined;
  };
  
  const exercise = findExercise();
  
  const findLevelAndDay = () => {
    for (const level of workoutLevels) {
      for (const day of level.days) {
        const found = day.exercises.find(ex => ex.id === exerciseId);
        if (found) return { level: level.title, day: day.name };
      }
    }
    return { level: '', day: '' };
  };
  
  const { level: currentLevel, day: currentDay } = findLevelAndDay();
  
  useEffect(() => {
    if (exercise && exerciseId) {
      setReps(exercise.reps);
      
      // Load saved progress
      const progress = getSeriesProgress(exerciseId);
      setSeriesCompleted(progress.seriesCompleted);
    }
  }, [exercise, exerciseId]);

  // Handle missing exercise ID
  if (!exerciseId || !exercise) {
    return (
      <div className="nova-gradient min-h-screen flex flex-col items-center justify-center p-6">
        <h1 className="text-2xl font-poppins font-bold text-white text-shadow mb-4">
          Ejercicio no encontrado
        </h1>
        <GoldenButton onClick={() => navigate('/routine')}>
          Volver a rutina
        </GoldenButton>
      </div>
    );
  }
  
  const handleBack = () => {
    navigate('/routine');
  };
  
  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };
  
  const handleIntensityChange = (value: number) => {
    setIntensity(value);
  };

  const handleSeriesClick = () => {
    let newSeriesCount = seriesCompleted + 1;
    
    // Si llegamos a 3, marcar como completado
    if (newSeriesCount >= 3) {
      newSeriesCount = 3;
    }
    
    setSeriesCompleted(newSeriesCount);
    
    // Save progress
    if (exerciseId && currentLevel && currentDay) {
      saveSeriesProgress(exerciseId, newSeriesCount, currentLevel, currentDay);
    }
    
    // Si completó 3/3, mostrar efecto y regresar automáticamente
    if (newSeriesCount === 3) {
      setShowWaveEffect(true);
      toast.success('¡Ejercicio completado! 🎉', {
        duration: 2000,
      });
      
      // Regresar automáticamente después de 2 segundos
      setTimeout(() => {
        navigate('/routine');
      }, 2000);
    }
  };

  const getSeriesButtonText = () => {
    if (seriesCompleted === 3) {
      return `3/3 ✅`;
    }
    return `${seriesCompleted}/3`;
  };

  const getSeriesButtonStyle = () => {
    if (seriesCompleted === 3) {
      return 'bg-green-600 hover:bg-green-700 border-green-500';
    } else {
      return 'bg-red-600 hover:bg-red-700 border-red-500';
    }
  };

  const handleImageLoad = () => {
    setIsImageLoading(false);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };
  
  const handleTouchMove = (e: React.TouchEvent) => {
    if (!touchStartX.current) return;
    
    const touchEndX = e.touches[0].clientX;
    const diff = touchStartX.current - touchEndX;
    
    if (Math.abs(diff) > 50) {
      touchStartX.current = null;
      navigate('/routine');
    }
  };
  
  const handleTouchEnd = () => {
    touchStartX.current = null;
  };
  
  const handleRepsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setReps(e.target.value);
  };

  const getEquipmentEmoji = () => {
    switch(exercise.equipment) {
      case 'weights': return '🏋️‍♂️';
      case 'bodyweight': return '🤸‍♀️';
      case 'machine': return '🏋️‍♀️';
      default: return '🏋️';
    }
  };

  return (
    <div 
      className={`nova-gradient min-h-screen flex flex-col ${showWaveEffect ? 'animate-wave' : ''}`}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Header with back button */}
      <header className="pt-12 pb-4 px-4 flex items-center">
        <button onClick={handleBack} className="p-2">
          <ArrowLeft size={24} className="text-white" />
        </button>
        <h1 className="flex-1 text-xl font-poppins font-bold text-white text-shadow text-center ml-2">
          {exercise.name}
        </h1>
        <div className="p-2">
          {/* Placeholder for future features */}
        </div>
      </header>
      
      {/* Exercise GIF */}
      <div className="relative">
        <div className="aspect-video max-h-64 w-full bg-black/20 overflow-hidden">
          {isImageLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/30">
              <div className="text-5xl animate-pulse">{getEquipmentEmoji()}</div>
            </div>
          )}
          <img 
            src={exercise.image} 
            alt={exercise.name} 
            className="w-full h-full object-cover"
            onLoad={handleImageLoad}
            style={{ opacity: isImageLoading ? 0 : 1 }}
          />
        </div>
        
        {/* Playback controls */}
        <div className="absolute bottom-4 right-4 bg-black/30 rounded-full p-2" onClick={togglePlayPause}>
          {isPlaying ? <Pause size={24} className="text-white" /> : <Play size={24} className="text-white" />}
        </div>
      </div>
      
      {/* Exercise info */}
      <div className="flex-1 p-4 space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="font-poppins font-bold text-lg text-white text-shadow">Instrucciones</h2>
          <div className="flex items-center">
            <input
              type="text"
              value={reps}
              onChange={handleRepsChange}
              className="w-20 px-3 py-1 bg-white/20 rounded-full text-sm text-center text-white"
            />
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <button className="ml-2 text-white/80 hover:text-white">
                    <Info size={16} />
                  </button>
                </TooltipTrigger>
                <TooltipContent className="bg-gray-800 text-white border-gray-700">
                  <p>Edita las series y repeticiones</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
        
        {/* Cronómetro */}
        <div>
          <h3 className="text-left text-sm text-white/80 mb-3">Cronómetro de ejercicio</h3>
          <ExerciseTimer 
            duration={timerDuration}
            onComplete={() => toast.success('¡Tiempo completado!')}
          />
        </div>
        
        {/* Steps */}
        <div className="bg-white/10 p-4 rounded-nova">
          {exercise.steps.map((step) => (
            <div key={step.step} className="flex mb-3 last:mb-0">
              <div className="mr-3 font-bold text-xl">{step.emoji}</div>
              <div className="text-left text-white">
                {step.description}
              </div>
            </div>
          ))}
        </div>
        
        {/* Muscle groups */}
        <div>
          <h3 className="text-left text-sm text-white/80 mb-1">Grupos musculares</h3>
          <p className="text-left text-white">{exercise.muscleGroups}</p>
        </div>
        
        {/* Intensity slider */}
        <div className="bg-white/10 p-4 rounded-nova">
          <IntensitySlider 
            onChange={handleIntensityChange}
            initialValue={intensity}
          />
        </div>

        {/* Exercise tips */}
        {exercise.tips && (
          <div className="bg-white/10 p-3 rounded-nova">
            <div className="flex items-start">
              <span className="text-xl mr-2">💡</span>
              <p className="text-left text-white text-sm">{exercise.tips}</p>
            </div>
          </div>
        )}
      </div>
      
      {/* Series Counter Button - Solo si no está completado */}
      {seriesCompleted < 3 && (
        <div className="p-4">
          <button
            onClick={handleSeriesClick}
            className={`w-full py-6 px-8 rounded-nova font-bold text-2xl text-white border-2 transition-all duration-300 ${getSeriesButtonStyle()}`}
          >
            {getSeriesButtonText()}
          </button>
        </div>
      )}
      
      {/* Back button - Solo si está completado */}
      {seriesCompleted >= 3 && (
        <div className="p-4">
          <GoldenButton 
            onClick={handleBack}
            fullWidth
          >
            ¡Completado! Volver a Rutina
          </GoldenButton>
        </div>
      )}
    </div>
  );
};

export default ExerciseDetailScreen;
