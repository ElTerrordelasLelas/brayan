
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Play, Calendar, BarChart3, Users, User, Settings, LogOut } from 'lucide-react';
import GoldenButton from '../components/GoldenButton';
import LoginModal from '../components/LoginModal';
import ProfileEditModal from '../components/ProfileEditModal';
import LevelTestModal from '../components/LevelTestModal';
import QuickExerciseModal from '../components/QuickExerciseModal';
import FAQModal from '../components/FAQModal';
import ParticleEffect from '../components/ParticleEffect';
import { useAuth } from '../components/AuthProvider';
import { signOut } from '../services/authService';
import { toast } from 'sonner';

const Index: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated, isLoading } = useAuth();
  const [showLogin, setShowLogin] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showLevelTest, setShowLevelTest] = useState(false);
  const [showQuickExercise, setShowQuickExercise] = useState(false);
  const [showFAQ, setShowFAQ] = useState(false);

  const handleStartTraining = () => {
    navigate('/level-selection');
  };

  const handleScheduleAppointment = () => {
    navigate('/schedule');
  };

  const handleViewProgress = () => {
    navigate('/progress');
  };

  const handleViewTrainers = () => {
    navigate('/trainers');
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      toast.success('Sesión cerrada exitosamente');
    } catch (error) {
      console.error('Error signing out:', error);
      toast.error('Error al cerrar sesión');
    }
  };

  const handleRoutineAccess = () => {
    // Always allow access to routine, whether authenticated or not
    navigate('/routine');
  };

  const handleLevelTestComplete = (level: number) => {
    toast.success(`Nivel ${level + 1} asignado`);
    setShowLevelTest(false);
    // Optionally save the level to user preferences
  };

  if (isLoading) {
    return (
      <div className="nova-gradient min-h-screen flex items-center justify-center">
        <div className="text-white text-center">
          <p>Cargando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="nova-gradient min-h-screen relative overflow-hidden">
      <ParticleEffect />
      
      {/* Header */}
      <header className="relative z-10 pt-12 pb-8 px-6">
        <div className="flex items-center justify-between mb-8">
          <div className="flex-1">
            <h1 className="text-3xl font-nunito font-bold text-white mb-2">
              Hola {isAuthenticated ? (user?.email?.split('@')[0] || 'Usuario') : 'Invitado'} 👋
            </h1>
            <p className="text-nova-lightGray">
              {isAuthenticated ? '¡Listo para entrenar hoy!' : '¡Únete y comienza tu transformación!'}
            </p>
          </div>
          
          <div className="flex items-center space-x-2">
            {isAuthenticated ? (
              <>
                <button
                  onClick={() => setShowProfile(true)}
                  className="p-3 bg-white/10 rounded-nova backdrop-blur-sm hover:bg-white/20 transition-all duration-300"
                >
                  <User size={20} className="text-white" />
                </button>
                <button
                  onClick={handleSignOut}
                  className="p-3 bg-white/10 rounded-nova backdrop-blur-sm hover:bg-white/20 transition-all duration-300"
                >
                  <LogOut size={20} className="text-white" />
                </button>
              </>
            ) : (
              <button
                onClick={() => setShowLogin(true)}
                className="px-4 py-2 bg-nova-gold text-black rounded-nova font-medium hover:bg-nova-gold/80 transition-all duration-300"
              >
                Iniciar Sesión
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 px-6 pb-8">
        {/* Quick Actions Grid */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <button
            onClick={handleStartTraining}
            className="nova-card p-6 text-left group floating-card"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-nova-red rounded-nova">
                <Play className="h-6 w-6 text-white" fill="white" />
              </div>
            </div>
            <h3 className="font-nunito font-bold text-white text-lg mb-2">Seleccionar Nivel</h3>
            <p className="text-nova-lightGray text-sm">Elige tu nivel de entrenamiento</p>
          </button>

          <button
            onClick={handleRoutineAccess}
            className="nova-card p-6 text-left group floating-card"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-nova-gold rounded-nova">
                <Settings className="h-6 w-6 text-black" />
              </div>
            </div>
            <h3 className="font-nunito font-bold text-white text-lg mb-2">Entrenamientos</h3>
            <p className="text-nova-lightGray text-sm">
              Acceso completo a rutinas y progreso
            </p>
          </button>

          <button
            onClick={handleScheduleAppointment}
            className="nova-card p-6 text-left group floating-card"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-purple-600 rounded-nova">
                <Calendar className="h-6 w-6 text-white" />
              </div>
            </div>
            <h3 className="font-nunito font-bold text-white text-lg mb-2">Citas</h3>
            <p className="text-nova-lightGray text-sm">Agenda tu entrenamiento</p>
          </button>

          <button
            onClick={handleViewProgress}
            className="nova-card p-6 text-left group floating-card"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-green-600 rounded-nova">
                <BarChart3 className="h-6 w-6 text-white" />
              </div>
            </div>
            <h3 className="font-nunito font-bold text-white text-lg mb-2">Progreso</h3>
            <p className="text-nova-lightGray text-sm">Ve tu evolución en tiempo real</p>
          </button>
        </div>

        {/* Action Buttons */}
        <div className="space-y-4">
          <GoldenButton 
            onClick={handleViewTrainers}
            className="w-full flex items-center justify-center"
          >
            <Users className="w-5 h-5 mr-2" />
            Ver Entrenadores
          </GoldenButton>

          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => setShowLevelTest(true)}
              className="px-4 py-3 bg-white/10 text-white rounded-nova backdrop-blur-sm hover:bg-white/20 transition-all duration-300"
            >
              Test de Nivel
            </button>
            <button
              onClick={() => setShowQuickExercise(true)}
              className="px-4 py-3 bg-white/10 text-white rounded-nova backdrop-blur-sm hover:bg-white/20 transition-all duration-300"
            >
              Ejercicio Rápido
            </button>
          </div>

          <button
            onClick={() => setShowFAQ(true)}
            className="w-full px-4 py-3 bg-white/10 text-white rounded-nova backdrop-blur-sm hover:bg-white/20 transition-all duration-300"
          >
            Preguntas Frecuentes
          </button>
        </div>
      </main>

      {/* Modals */}
      <LoginModal 
        isOpen={showLogin} 
        onClose={() => setShowLogin(false)} 
      />
      <ProfileEditModal 
        isOpen={showProfile} 
        onClose={() => setShowProfile(false)} 
      />
      <LevelTestModal 
        isOpen={showLevelTest} 
        onClose={() => setShowLevelTest(false)}
        onComplete={handleLevelTestComplete}
      />
      <QuickExerciseModal 
        isOpen={showQuickExercise} 
        onClose={() => setShowQuickExercise(false)} 
      />
      <FAQModal 
        isOpen={showFAQ} 
        onClose={() => setShowFAQ(false)} 
      />
    </div>
  );
};

export default Index;
