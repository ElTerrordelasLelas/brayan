
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import LevelCard from '../components/LevelCard';
import { workoutLevels } from '../data/workoutRoutines';
import { saveSelectedLevel, getUserLevel } from '../services/levelService';
import { useAuth } from '../components/AuthProvider';
import { toast } from 'sonner';

const LevelSelectionScreen = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated, isLoading } = useAuth();
  const [isCheckingLevel, setIsCheckingLevel] = useState(true);
  const [isSelectingLevel, setIsSelectingLevel] = useState(false);
  
  useEffect(() => {
    const checkExistingLevel = async () => {
      if (isLoading) return;
      
      console.log('Checking existing level for user:', user?.email);
      setIsCheckingLevel(true);
      
      try {
        const userLevel = await getUserLevel();
        console.log('Existing level check result:', userLevel);
        
        if (userLevel) {
          console.log('User already has level, redirecting to routine');
          toast.success(`Nivel ${userLevel.levelTitle} ya seleccionado`);
          navigate('/routine', { state: { levelIndex: userLevel.levelIndex } });
        } else {
          console.log('No existing level found, showing selection');
        }
      } catch (error) {
        console.error('Error checking existing level:', error);
        toast.error('Error al verificar nivel existente');
      } finally {
        setIsCheckingLevel(false);
      }
    };
    
    checkExistingLevel();
  }, [navigate, user, isLoading]);
  
  const handleLevelSelect = async (levelIndex: number) => {
    if (isSelectingLevel) return;
    
    setIsSelectingLevel(true);
    const selectedLevel = workoutLevels[levelIndex];
    
    console.log('Selecting level:', selectedLevel.title, 'Index:', levelIndex);
    toast.loading('Guardando nivel seleccionado...');
    
    try {
      // Guardar el nivel seleccionado
      const success = await saveSelectedLevel(levelIndex, selectedLevel.title);
      
      if (success) {
        console.log('Level saved successfully, navigating to routine');
        toast.dismiss();
        toast.success(`Nivel ${selectedLevel.title} seleccionado exitosamente`);
        
        // Navigate to routine screen with the selected level index
        navigate('/routine', { state: { levelIndex } });
        
        // Play confetti sound effect if available
        try {
          new Audio('/confetti-sound.mp3').play();
        } catch (e) {
          // Silent fail if audio not available or autoplay blocked
          console.log('Audio playback failed or blocked');
        }
      } else {
        toast.dismiss();
        toast.error('Error al guardar el nivel');
      }
    } catch (error) {
      console.error('Error selecting level:', error);
      toast.dismiss();
      toast.error('Error al seleccionar nivel');
    } finally {
      setIsSelectingLevel(false);
    }
  };

  // Mostrar loading mientras se verifica la autenticación o el nivel existente
  if (isLoading || isCheckingLevel) {
    return (
      <div className="p-6 max-w-4xl mx-auto flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-nova-gold mx-auto mb-4"></div>
          <p className="text-nova-gold">Verificando tu nivel...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-gothic uppercase tracking-wider mb-2">Selecciona tu Nivel</h1>
        <div className="gothic-divider"></div>
        <p className="text-nova-gold mt-4">Escoge el nivel de entrenamiento que mejor se ajuste a ti</p>
        {isAuthenticated && user && (
          <p className="text-nova-lightGray text-sm mt-2">
            Conectado como: {user.email}
          </p>
        )}
      </div>
      
      <div className="grid grid-cols-1 gap-6">
        {workoutLevels.map((level, index) => (
          <div key={level.id} className="gothic-card hover:border-nova-red transition-all duration-300">
            <LevelCard
              key={level.id}
              title={level.title}
              emoji={level.emoji}
              description={level.description}
              onClick={() => handleLevelSelect(index)}
              className={isSelectingLevel ? 'opacity-50 cursor-not-allowed' : ''}
            />
          </div>
        ))}
      </div>
      
      {isSelectingLevel && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-nova-darkGray p-6 rounded-nova text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-nova-gold mx-auto mb-4"></div>
            <p className="text-white">Guardando tu nivel...</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default LevelSelectionScreen;
