
import React, { useEffect, useState } from 'react';
import { Dumbbell } from 'lucide-react';
import ParticleEffect from '../components/ParticleEffect';

const SplashScreen: React.FC = () => {
  const [showParticles, setShowParticles] = useState(false);

  useEffect(() => {
    const particleTimeout = setTimeout(() => {
      setShowParticles(true);
    }, 500);

    return () => {
      clearTimeout(particleTimeout);
    };
  }, []);

  return (
    <div className="bg-nova-black min-h-screen flex flex-col items-center justify-center overflow-hidden relative">
      <div className="absolute inset-0 nova-gradient"></div>
      
      <div className="relative z-10 text-center animate-scale-in">
        <div className="flex items-center justify-center h-20 w-20 nova-button-gradient mx-auto mb-8 shadow-glow rounded-nova-xl animate-float">
          <Dumbbell className="h-12 w-12 text-white" strokeWidth={1.5} />
        </div>
        
        <h1 className="text-6xl md:text-7xl font-nunito font-bold uppercase tracking-wide text-white text-shadow-soft mb-4">
          NOVA <span className="gradient-text">ERA</span>
        </h1>
        
        <p className="text-nova-gold text-lg md:text-xl font-nunito font-light tracking-wider opacity-90">
          ENTRENAMIENTO DE ÉLITE
        </p>
        
        {showParticles && <ParticleEffect />}
        
        {/* Bordes orgánicos en lugar de líneas rectas */}
        <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-transparent via-nova-red/60 to-transparent rounded-full"></div>
        <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-transparent via-nova-red/60 to-transparent rounded-full"></div>
        <div className="absolute inset-y-0 left-0 w-1 bg-gradient-to-b from-transparent via-nova-red/60 to-transparent rounded-full"></div>
        <div className="absolute inset-y-0 right-0 w-1 bg-gradient-to-b from-transparent via-nova-red/60 to-transparent rounded-full"></div>
      </div>
    </div>
  );
};

export default SplashScreen;
