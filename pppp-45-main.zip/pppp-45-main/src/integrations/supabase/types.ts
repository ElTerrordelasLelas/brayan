export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      citas: {
        Row: {
          created_at: string | null
          entrenador_id: string
          estado: string | null
          fecha: string
          id: number
          notas: string | null
          tipo_entrenamiento: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          entrenador_id: string
          estado?: string | null
          fecha: string
          id?: number
          notas?: string | null
          tipo_entrenamiento?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          entrenador_id?: string
          estado?: string | null
          fecha?: string
          id?: number
          notas?: string | null
          tipo_entrenamiento?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      configuraciones_usuario: {
        Row: {
          altura: number | null
          experiencia_previa: number | null
          fecha_actualizacion: string | null
          fecha_creacion: string | null
          frecuencia_semanal: number | null
          id: string
          nivel_entrenamiento: string
          objetivo_principal: string | null
          peso_corporal: number | null
          user_id: string
        }
        Insert: {
          altura?: number | null
          experiencia_previa?: number | null
          fecha_actualizacion?: string | null
          fecha_creacion?: string | null
          frecuencia_semanal?: number | null
          id?: string
          nivel_entrenamiento: string
          objetivo_principal?: string | null
          peso_corporal?: number | null
          user_id: string
        }
        Update: {
          altura?: number | null
          experiencia_previa?: number | null
          fecha_actualizacion?: string | null
          fecha_creacion?: string | null
          frecuencia_semanal?: number | null
          id?: string
          nivel_entrenamiento?: string
          objetivo_principal?: string | null
          peso_corporal?: number | null
          user_id?: string
        }
        Relationships: []
      }
      ejercicios_pendientes: {
        Row: {
          descripcion: string | null
          id: string
          nivel: string
          nombre: string
          user_id: string | null
        }
        Insert: {
          descripcion?: string | null
          id: string
          nivel: string
          nombre: string
          user_id?: string | null
        }
        Update: {
          descripcion?: string | null
          id?: string
          nivel?: string
          nombre?: string
          user_id?: string | null
        }
        Relationships: []
      }
      marcas_personales: {
        Row: {
          ejercicio_nombre: string
          fecha_logro: string | null
          id: string
          notas: string | null
          tipo_marca: string
          unidad: string
          user_id: string
          valor: number
        }
        Insert: {
          ejercicio_nombre: string
          fecha_logro?: string | null
          id?: string
          notas?: string | null
          tipo_marca: string
          unidad: string
          user_id: string
          valor: number
        }
        Update: {
          ejercicio_nombre?: string
          fecha_logro?: string | null
          id?: string
          notas?: string | null
          tipo_marca?: string
          unidad?: string
          user_id?: string
          valor?: number
        }
        Relationships: []
      }
      medallas: {
        Row: {
          activa: boolean | null
          descripcion: string | null
          fecha_obtenida: string | null
          fecha_obtenida_real: string | null
          icono: string | null
          id: string
          nombre: string
          tipo_medalla: string
          tipo_medalla_id: string | null
          user_id: string
          valor_logro: Json | null
        }
        Insert: {
          activa?: boolean | null
          descripcion?: string | null
          fecha_obtenida?: string | null
          fecha_obtenida_real?: string | null
          icono?: string | null
          id?: string
          nombre: string
          tipo_medalla: string
          tipo_medalla_id?: string | null
          user_id: string
          valor_logro?: Json | null
        }
        Update: {
          activa?: boolean | null
          descripcion?: string | null
          fecha_obtenida?: string | null
          fecha_obtenida_real?: string | null
          icono?: string | null
          id?: string
          nombre?: string
          tipo_medalla?: string
          tipo_medalla_id?: string | null
          user_id?: string
          valor_logro?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "medallas_tipo_medalla_id_fkey"
            columns: ["tipo_medalla_id"]
            isOneToOne: false
            referencedRelation: "tipos_medallas"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          configuracion: Json | null
          created_at: string | null
          email: string | null
          fecha_registro: string | null
          fecha_seleccion_nivel: string | null
          id: string
          nivel_seleccionado: string | null
          nombre: string | null
          updated_at: string | null
        }
        Insert: {
          avatar_url?: string | null
          configuracion?: Json | null
          created_at?: string | null
          email?: string | null
          fecha_registro?: string | null
          fecha_seleccion_nivel?: string | null
          id: string
          nivel_seleccionado?: string | null
          nombre?: string | null
          updated_at?: string | null
        }
        Update: {
          avatar_url?: string | null
          configuracion?: Json | null
          created_at?: string | null
          email?: string | null
          fecha_registro?: string | null
          fecha_seleccion_nivel?: string | null
          id?: string
          nivel_seleccionado?: string | null
          nombre?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      progreso: {
        Row: {
          calificacion_esfuerzo: number | null
          duracion_min: number | null
          ejercicio_id: string
          fecha: string | null
          id: number
          intensidad: number | null
          nombre: string
          notas_sesion: string | null
          peso_utilizado: number | null
          repeticiones_realizadas: number | null
          series_completadas: number | null
          tiempo_descanso_seg: number | null
          user_id: string
        }
        Insert: {
          calificacion_esfuerzo?: number | null
          duracion_min?: number | null
          ejercicio_id: string
          fecha?: string | null
          id?: number
          intensidad?: number | null
          nombre: string
          notas_sesion?: string | null
          peso_utilizado?: number | null
          repeticiones_realizadas?: number | null
          series_completadas?: number | null
          tiempo_descanso_seg?: number | null
          user_id: string
        }
        Update: {
          calificacion_esfuerzo?: number | null
          duracion_min?: number | null
          ejercicio_id?: string
          fecha?: string | null
          id?: number
          intensidad?: number | null
          nombre?: string
          notas_sesion?: string | null
          peso_utilizado?: number | null
          repeticiones_realizadas?: number | null
          series_completadas?: number | null
          tiempo_descanso_seg?: number | null
          user_id?: string
        }
        Relationships: []
      }
      reservas_gimnasio: {
        Row: {
          created_at: string | null
          duracion_minutos: number | null
          estado: string | null
          fecha_hora: string
          id: string
          notas: string | null
          tipo_entrenamiento: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          duracion_minutos?: number | null
          estado?: string | null
          fecha_hora: string
          id?: string
          notas?: string | null
          tipo_entrenamiento?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          duracion_minutos?: number | null
          estado?: string | null
          fecha_hora?: string
          id?: string
          notas?: string | null
          tipo_entrenamiento?: string | null
          user_id?: string
        }
        Relationships: []
      }
      reservas_sesiones: {
        Row: {
          duracion_minutos: number
          estado: string
          fecha_creacion: string | null
          fecha_hora: string
          id: string
          notas: string | null
          recordatorio_1h: boolean | null
          recordatorio_24h: boolean | null
          tipo_entrenamiento: string
          user_id: string
        }
        Insert: {
          duracion_minutos?: number
          estado?: string
          fecha_creacion?: string | null
          fecha_hora: string
          id?: string
          notas?: string | null
          recordatorio_1h?: boolean | null
          recordatorio_24h?: boolean | null
          tipo_entrenamiento: string
          user_id: string
        }
        Update: {
          duracion_minutos?: number
          estado?: string
          fecha_creacion?: string | null
          fecha_hora?: string
          id?: string
          notas?: string | null
          recordatorio_1h?: boolean | null
          recordatorio_24h?: boolean | null
          tipo_entrenamiento?: string
          user_id?: string
        }
        Relationships: []
      }
      sesiones_entrenamiento: {
        Row: {
          calificacion_esfuerzo: number | null
          created_at: string | null
          dia_rutina: string
          duracion_minutos: number | null
          ejercicios_completados: number | null
          fecha: string | null
          id: string
          nivel: string
          notas: string | null
          total_ejercicios: number | null
          user_id: string
        }
        Insert: {
          calificacion_esfuerzo?: number | null
          created_at?: string | null
          dia_rutina: string
          duracion_minutos?: number | null
          ejercicios_completados?: number | null
          fecha?: string | null
          id?: string
          nivel: string
          notas?: string | null
          total_ejercicios?: number | null
          user_id: string
        }
        Update: {
          calificacion_esfuerzo?: number | null
          created_at?: string | null
          dia_rutina?: string
          duracion_minutos?: number | null
          ejercicios_completados?: number | null
          fecha?: string | null
          id?: string
          nivel?: string
          notas?: string | null
          total_ejercicios?: number | null
          user_id?: string
        }
        Relationships: []
      }
      tipos_medallas: {
        Row: {
          created_at: string | null
          criterio_tipo: string
          criterio_valor: number
          descripcion: string | null
          icono: string | null
          id: string
          nombre: string
          tipo_medalla: string
          valor_logro: Json | null
        }
        Insert: {
          created_at?: string | null
          criterio_tipo: string
          criterio_valor: number
          descripcion?: string | null
          icono?: string | null
          id?: string
          nombre: string
          tipo_medalla: string
          valor_logro?: Json | null
        }
        Update: {
          created_at?: string | null
          criterio_tipo?: string
          criterio_valor?: number
          descripcion?: string | null
          icono?: string | null
          id?: string
          nombre?: string
          tipo_medalla?: string
          valor_logro?: Json | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      verificar_medallas_usuario: {
        Args: { usuario_id: string }
        Returns: undefined
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
