
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://klonssqgynzbbimkebcg.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imtsb25zc3FneW56YmJpbWtlYmNnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg4OTY0NjIsImV4cCI6MjA2NDQ3MjQ2Mn0.ejK0wmqk4MXx_CiZlpDveTLMuxzxlBMBb0X1U8YGiiw'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)
