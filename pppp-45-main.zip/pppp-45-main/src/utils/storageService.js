
// ===== UTILIDADES DE ALMACENAMIENTO =====
export const initializeStorage = () => {
  // Inicializar claves necesarias si no existen
  if (!localStorage.getItem('progreso_real')) {
    localStorage.setItem('progreso_real', '[]');
  }
  if (!localStorage.getItem('ejercicios_pendientes')) {
    localStorage.setItem('ejercicios_pendientes', '[]');
  }
  if (!localStorage.getItem('citas')) {
    localStorage.setItem('citas', '[]');
  }
  if (!localStorage.getItem('users')) {
    localStorage.setItem('users', '[]');
  }
};

export const exportarDatos = () => {
  return {
    progreso: JSON.parse(localStorage.getItem('progreso_real') || '[]'),
    citas: JSON.parse(localStorage.getItem('citas') || '[]'),
    pendientes: JSON.parse(localStorage.getItem('ejercicios_pendientes') || '[]'),
    usuarios: JSON.parse(localStorage.getItem('users') || '[]')
  };
};

export const importarDatos = (datos) => {
  if (datos.progreso) localStorage.setItem('progreso_real', JSON.stringify(datos.progreso));
  if (datos.citas) localStorage.setItem('citas', JSON.stringify(datos.citas));
  if (datos.pendientes) localStorage.setItem('ejercicios_pendientes', JSON.stringify(datos.pendientes));
  if (datos.usuarios) localStorage.setItem('users', JSON.stringify(datos.usuarios));
  
  // [SUPABASE]: Reemplazar esta función al conectar
  syncDataToCloud(datos);
};

export const clearAllData = () => {
  localStorage.removeItem('progreso_real');
  localStorage.removeItem('citas');
  localStorage.removeItem('ejercicios_pendientes');
  localStorage.removeItem('users');
  localStorage.removeItem('currentUser');
  
  // [SUPABASE]: Reemplazar esta función al conectar
  clearAllCloudData();
};

// [SUPABASE]: Reemplazar estas funciones al conectar
const syncDataToCloud = (datos) => {
  /* temporalmente vacío */
};

const clearAllCloudData = () => {
  /* temporalmente vacío */
};

