
// ===== EJERCICIOS COMPLETADOS =====
export const completarEjercicio = (ejercicioId, datosEjercicio) => {
  // Obtener ejercicios pendientes
  const pendientes = JSON.parse(localStorage.getItem('ejercicios_pendientes')) || [];
  
  // Quitar de pendientes
  const pendientesActualizados = pendientes.filter(ej => ej.id !== ejercicioId);
  localStorage.setItem('ejercicios_pendientes', JSON.stringify(pendientesActualizados));
  
  // Agregar a completados
  const completados = JSON.parse(localStorage.getItem('progreso_real')) || [];
  const ejercicioCompletado = {
    id: ejercicioId,
    nombre: datosEjercicio.nombre,
    fecha: new Date().toISOString(),
    intensidad: datosEjercicio.intensidad || 3
  };
  
  completados.push(ejercicioCompletado);
  localStorage.setItem('progreso_real', JSON.stringify(completados));
  
  // [SUPABASE]: Reemplazar esta función al conectar
  saveCompletedExerciseToCloud(ejercicioCompletado);
  
  return ejercicioCompletado;
};

export const getEjerciciosPendientes = () => {
  return JSON.parse(localStorage.getItem('ejercicios_pendientes')) || [];
};

export const addEjercicioPendiente = (ejercicio) => {
  const pendientes = JSON.parse(localStorage.getItem('ejercicios_pendientes')) || [];
  const nuevoEjercicio = {
    id: "ej_" + Date.now(),
    ...ejercicio
  };
  pendientes.push(nuevoEjercicio);
  localStorage.setItem('ejercicios_pendientes', JSON.stringify(pendientes));
  return nuevoEjercicio;
};

// [SUPABASE]: Reemplazar esta función al conectar
const saveCompletedExerciseToCloud = (ejercicio) => {
  /* temporalmente vacío */
};

