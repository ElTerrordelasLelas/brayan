
/**
 * Utility script to replace all instances of "Lovable" with "Design" across the codebase
 * This script recursively searches through files and replaces text case-sensitively
 */

interface FileReplaceOptions {
  directory: string;
  oldText: string;
  newText: string;
  fileExtensions?: string[];
  excludeDirectories?: string[];
}

export class TextReplacer {
  private static readonly DEFAULT_EXTENSIONS = [
    '.html', '.htm', '.js', '.jsx', '.ts', '.tsx', 
    '.css', '.scss', '.sass', '.json', '.md', '.txt',
    '.xml', '.svg', '.vue', '.php', '.py', '.java',
    '.c', '.cpp', '.h', '.hpp', '.cs', '.rb', '.go'
  ];

  private static readonly DEFAULT_EXCLUDE_DIRS = [
    'node_modules', '.git', 'dist', 'build', '.next', 
    '.cache', 'coverage', '.nyc_output', 'public/lovable-uploads'
  ];

  /**
   * Replaces text in all files within a directory
   */
  static async replaceInDirectory(options: FileReplaceOptions): Promise<void> {
    const {
      directory = '.',
      oldText,
      newText,
      fileExtensions = this.DEFAULT_EXTENSIONS,
      excludeDirectories = this.DEFAULT_EXCLUDE_DIRS
    } = options;

    console.log(`🔍 Searching for "${oldText}" to replace with "${newText}"`);
    console.log(`📁 Directory: ${directory}`);
    console.log(`📄 File extensions: ${fileExtensions.join(', ')}`);
    console.log(`🚫 Excluding directories: ${excludeDirectories.join(', ')}`);

    try {
      const results = await this.processDirectory(
        directory, 
        oldText, 
        newText, 
        fileExtensions, 
        excludeDirectories
      );
      
      console.log(`\n✅ Replacement complete!`);
      console.log(`📊 Files processed: ${results.filesProcessed}`);
      console.log(`🔄 Files modified: ${results.filesModified}`);
      console.log(`📝 Total replacements: ${results.totalReplacements}`);
      
    } catch (error) {
      console.error('❌ Error during replacement:', error);
    }
  }

  private static async processDirectory(
    directory: string,
    oldText: string,
    newText: string,
    fileExtensions: string[],
    excludeDirectories: string[]
  ): Promise<{ filesProcessed: number; filesModified: number; totalReplacements: number }> {
    let filesProcessed = 0;
    let filesModified = 0;
    let totalReplacements = 0;

    // Note: This is a template for the logic. In a real implementation,
    // you would use Node.js filesystem APIs (fs.readdir, fs.readFile, fs.writeFile)
    // or browser File API depending on your environment.

    console.log(`\n🔧 To actually run this replacement, you would need to:`);
    console.log(`1. Use this script in a Node.js environment`);
    console.log(`2. Install required dependencies (if any)`);
    console.log(`3. Run with proper filesystem access`);
    
    // Example implementation structure:
    /*
    const files = await fs.readdir(directory, { withFileTypes: true });
    
    for (const file of files) {
      if (file.isDirectory()) {
        if (!excludeDirectories.includes(file.name)) {
          const subResults = await this.processDirectory(
            path.join(directory, file.name),
            oldText, newText, fileExtensions, excludeDirectories
          );
          filesProcessed += subResults.filesProcessed;
          filesModified += subResults.filesModified;
          totalReplacements += subResults.totalReplacements;
        }
      } else {
        const ext = path.extname(file.name);
        if (fileExtensions.includes(ext)) {
          const filePath = path.join(directory, file.name);
          const result = await this.processFile(filePath, oldText, newText);
          filesProcessed++;
          if (result.replacements > 0) {
            filesModified++;
            totalReplacements += result.replacements;
          }
        }
      }
    }
    */

    return { filesProcessed, filesModified, totalReplacements };
  }

  /**
   * Manual replacement helper - shows what would be replaced
   */
  static showReplacementPreview(text: string, oldText: string, newText: string): void {
    const regex = new RegExp(oldText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
    const matches = text.match(regex);
    
    if (matches) {
      console.log(`Found ${matches.length} instances of "${oldText}":`);
      matches.forEach((match, index) => {
        console.log(`  ${index + 1}. "${match}" → "${newText}"`);
      });
    } else {
      console.log(`No instances of "${oldText}" found in the provided text.`);
    }
  }
}

// Quick usage example function
export const replaceLovableWithDesign = () => {
  TextReplacer.replaceInDirectory({
    directory: '.',
    oldText: 'Lovable',
    newText: 'Design',
    fileExtensions: ['.html', '.js', '.jsx', '.ts', '.tsx', '.css', '.json', '.md'],
    excludeDirectories: ['node_modules', '.git', 'dist', 'build', 'public/lovable-uploads']
  });
};

// Console command helper
export const runReplacement = () => {
  console.log('🚀 Starting replacement of "Lovable" with "Design"...');
  replaceLovableWithDesign();
};
