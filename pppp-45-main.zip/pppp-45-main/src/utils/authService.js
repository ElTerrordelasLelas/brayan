
// ===== SISTEMA DE LOGIN TEMPORAL =====
export const registrarUsuario = (email, password) => {
  const usuarios = JSON.parse(localStorage.getItem('users')) || [];
  
  // Verificar si el usuario ya existe
  const usuarioExistente = usuarios.find(user => user.email === email);
  if (usuarioExistente) {
    throw new Error('El usuario ya existe');
  }
  
  const nuevoUsuario = {
    id: "user_" + Date.now(),
    email,
    password: btoa(password), // Encriptación básica
    fechaRegistro: new Date().toISOString()
  };
  
  usuarios.push(nuevoUsuario);
  localStorage.setItem('users', JSON.stringify(usuarios));
  localStorage.setItem('currentUser', JSON.stringify(nuevoUsuario));
  
  // [SUPABASE]: Reemplazar esta función al conectar
  saveUserToCloud(nuevoUsuario);
  
  return nuevoUsuario;
};

export const loginUsuario = (email, password) => {
  const usuarios = JSON.parse(localStorage.getItem('users')) || [];
  const usuario = usuarios.find(user => 
    user.email === email && user.password === btoa(password)
  );
  
  if (!usuario) {
    throw new Error('Credenciales incorrectas');
  }
  
  localStorage.setItem('currentUser', JSON.stringify(usuario));
  return usuario;
};

export const loginConGoogle = () => {
  // Botón MOCK para Google Login
  alert('Login con Google (habilitado al conectar Supabase)');
  
  // [SUPABASE]: Reemplazar esta función al conectar
  return googleAuthWithSupabase();
};

export const getCurrentUser = () => {
  return JSON.parse(localStorage.getItem('currentUser'));
};

export const logout = () => {
  localStorage.removeItem('currentUser');
  // [SUPABASE]: Reemplazar esta función al conectar
  logoutFromCloud();
};

export const migrarDatosInvitado = (usuarioId) => {
  // Migrar datos de invitado a usuario registrado
  const progreso = getProgresoReal();
  const citas = getCitas();
  
  // Actualizar referencias de usuario invitado
  const citasActualizadas = citas.map(cita => ({
    ...cita,
    usuario: cita.usuario.startsWith('invitado_') ? usuarioId : cita.usuario
  }));
  
  localStorage.setItem('citas', JSON.stringify(citasActualizadas));
  
  // [SUPABASE]: Reemplazar esta función al conectar
  migrateGuestDataToCloud(usuarioId, progreso, citasActualizadas);
};

// [SUPABASE]: Reemplazar estas funciones al conectar
const saveUserToCloud = (usuario) => {
  /* temporalmente vacío */
};

const googleAuthWithSupabase = () => {
  /* temporalmente vacío */
  return null;
};

const logoutFromCloud = () => {
  /* temporalmente vacío */
};

const migrateGuestDataToCloud = (usuarioId, progreso, citas) => {
  /* temporalmente vacío */
};

