
// ===== AGENDAR CITAS =====
export const agendarCita = (nuevaCita) => {
  const citas = JSON.parse(localStorage.getItem('citas')) || [];
  
  // Validar solapamientos de horarios
  const fechaNueva = new Date(nuevaCita.fecha);
  const conflicto = citas.find(cita => {
    const fechaExistente = new Date(cita.fecha);
    const diferenciaHoras = Math.abs(fechaNueva - fechaExistente) / (1000 * 60 * 60);
    return cita.entrenador === nuevaCita.entrenador && diferenciaHoras < 1;
  });
  
  if (conflicto) {
    throw new Error('El entrenador ya tiene una cita en ese horario');
  }
  
  const cita = {
    id: "cita_" + Date.now(),
    entrenador: nuevaCita.entrenador,
    fecha: nuevaCita.fecha,
    usuario: nuevaCita.usuario || "invitado_" + Date.now()
  };
  
  citas.push(cita);
  localStorage.setItem('citas', JSON.stringify(citas));
  
  // [SUPABASE]: Reemplazar esta función al conectar
  saveAppointmentToCloud(cita);
  
  return cita;
};

export const getCitas = () => {
  return JSON.parse(localStorage.getItem('citas')) || [];
};

export const cancelarCita = (citaId) => {
  const citas = JSON.parse(localStorage.getItem('citas')) || [];
  const citasActualizadas = citas.filter(cita => cita.id !== citaId);
  localStorage.setItem('citas', JSON.stringify(citasActualizadas));
  
  // [SUPABASE]: Reemplazar esta función al conectar
  deleteAppointmentFromCloud(citaId);
};

// [SUPABASE]: Reemplazar esta función al conectar
const saveAppointmentToCloud = (cita) => {
  /* temporalmente vacío */
};

// [SUPABASE]: Reemplazar esta función al conectar
const deleteAppointmentFromCloud = (citaId) => {
  /* temporalmente vacío */
};

