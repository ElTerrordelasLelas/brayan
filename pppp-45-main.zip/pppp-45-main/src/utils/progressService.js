
// ===== PROGRESO REAL =====
export const getProgresoReal = () => {
  return JSON.parse(localStorage.getItem('progreso_real')) || [];
};

export const getProgresoSemanal = () => {
  const progreso = getProgresoReal();
  const ahora = new Date();
  const inicioDeSemana = new Date(ahora.setDate(ahora.getDate() - ahora.getDay()));
  
  const ejerciciosSemana = progreso.filter(ejercicio => {
    const fechaEjercicio = new Date(ejercicio.fecha);
    return fechaEjercicio >= inicioDeSemana;
  });
  
  // Calcular días activos
  const diasConEjercicios = new Set();
  ejerciciosSemana.forEach(ejercicio => {
    const dia = new Date(ejercicio.fecha).toDateString();
    diasConEjercicios.add(dia);
  });
  
  // Calcular intensidad promedio
  const intensidadPromedio = ejerciciosSemana.length > 0 
    ? ejerciciosSemana.reduce((sum, ej) => sum + ej.intensidad, 0) / ejerciciosSemana.length
    : 0;
  
  return {
    diasActivos: diasConEjercicios.size,
    diasInactivos: 7 - diasConEjercicios.size,
    intensidadPromedio: Math.round(intensidadPromedio * 10) / 10,
    totalEjercicios: ejerciciosSemana.length,
    ejercicios: ejerciciosSemana
  };
};

export const getProgresoMensual = () => {
  const progreso = getProgresoReal();
  const ahora = new Date();
  const inicioDelMes = new Date(ahora.getFullYear(), ahora.getMonth(), 1);
  
  const ejerciciosMes = progreso.filter(ejercicio => {
    const fechaEjercicio = new Date(ejercicio.fecha);
    return fechaEjercicio >= inicioDelMes;
  });
  
  return {
    totalEjercicios: ejerciciosMes.length,
    ejercicios: ejerciciosMes
  };
};

export const clearProgreso = () => {
  localStorage.removeItem('progreso_real');
  // [SUPABASE]: Reemplazar esta función al conectar
  clearProgressFromCloud();
};

// [SUPABASE]: Reemplazar esta función al conectar
const clearProgressFromCloud = () => {
  /* temporalmente vacío */
};

