
// ===== EXPORTACIONES PRINCIPALES =====
export * from './appointmentService.js';
export * from './exerciseService.js';
export * from './progressService.js';
export * from './authService.js';
export * from './storageService.js';

// Inicializar almacenamiento al importar
import { initializeStorage } from './storageService.js';
initializeStorage();

