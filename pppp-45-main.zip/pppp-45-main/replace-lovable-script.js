
#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

/**
 * Standalone Node.js script to replace "Lovable" with "Design" across all code files
 * Usage: node replace-lovable-script.js
 */

class FileReplacer {
  constructor() {
    this.fileExtensions = [
      '.html', '.htm', '.js', '.jsx', '.ts', '.tsx', 
      '.css', '.scss', '.sass', '.json', '.md', '.txt',
      '.xml', '.svg', '.vue', '.php', '.py', '.java',
      '.c', '.cpp', '.h', '.hpp', '.cs', '.rb', '.go'
    ];
    
    this.excludeDirectories = [
      'node_modules', '.git', 'dist', 'build', '.next', 
      '.cache', 'coverage', '.nyc_output', 'public/lovable-uploads',
      'bun.lockb', 'package-lock.json'
    ];
    
    this.filesProcessed = 0;
    this.filesModified = 0;
    this.totalReplacements = 0;
  }

  async replaceInDirectory(directory, oldText, newText) {
    console.log(`🔍 Searching for "${oldText}" to replace with "${newText}"`);
    console.log(`📁 Directory: ${directory}`);
    console.log(`📄 File extensions: ${this.fileExtensions.join(', ')}`);
    console.log(`🚫 Excluding directories: ${this.excludeDirectories.join(', ')}\n`);

    try {
      await this.processDirectory(directory, oldText, newText);
      
      console.log(`\n✅ Replacement complete!`);
      console.log(`📊 Files processed: ${this.filesProcessed}`);
      console.log(`🔄 Files modified: ${this.filesModified}`);
      console.log(`📝 Total replacements: ${this.totalReplacements}`);
      
    } catch (error) {
      console.error('❌ Error during replacement:', error);
    }
  }

  async processDirectory(directory, oldText, newText) {
    const items = await fs.promises.readdir(directory, { withFileTypes: true });
    
    for (const item of items) {
      const fullPath = path.join(directory, item.name);
      
      if (item.isDirectory()) {
        if (!this.excludeDirectories.includes(item.name)) {
          await this.processDirectory(fullPath, oldText, newText);
        }
      } else {
        const ext = path.extname(item.name);
        if (this.fileExtensions.includes(ext)) {
          await this.processFile(fullPath, oldText, newText);
        }
      }
    }
  }

  async processFile(filePath, oldText, newText) {
    try {
      const content = await fs.promises.readFile(filePath, 'utf8');
      const originalContent = content;
      
      // Case-sensitive replacement
      const newContent = content.replace(new RegExp(oldText, 'g'), newText);
      
      this.filesProcessed++;
      
      if (newContent !== originalContent) {
        await fs.promises.writeFile(filePath, newContent, 'utf8');
        const replacements = (originalContent.match(new RegExp(oldText, 'g')) || []).length;
        this.filesModified++;
        this.totalReplacements += replacements;
        console.log(`✏️  Modified: ${filePath} (${replacements} replacements)`);
      }
      
    } catch (error) {
      if (error.code !== 'EISDIR') {
        console.error(`❌ Error processing ${filePath}:`, error.message);
      }
    }
  }
}

// Main execution
async function main() {
  console.log('🚀 Starting replacement of "Lovable" with "Design"...\n');
  
  const replacer = new FileReplacer();
  await replacer.replaceInDirectory('.', 'Lovable', 'Design');
  
  console.log('\n🎉 Script completed successfully!');
  console.log('💡 Tip: Review the changes and test your application to ensure everything works correctly.');
}

// Run the script
if (require.main === module) {
  main().catch(console.error);
}

module.exports = { FileReplacer };
